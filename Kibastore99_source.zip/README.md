# Kiba Official Store

Mobile Legends Bang Bang diamond top-up store built with React + Vite + Firebase + Tailwind CSS v4.

## Quick Start

```bash
npm install
npm run dev
```

## Build for Production

```bash
npm run build
```

## Deploy to Vercel

1. Push this folder to a GitHub repo
2. Import the repo on [vercel.com](https://vercel.com)
3. Vercel detects Vite automatically — no extra config needed
4. Add your production domain to Firebase Auth → Authorized domains

## Firebase

Firebase config is in `firebase-applet-config.json`.  
Go to Firebase Console → Authentication → Settings → Authorized domains and add your Vercel domain.

## Stack

- React 19 + Vite 7
- Firebase 11 (Auth + Firestore)
- Tailwind CSS v4
- Motion (Framer Motion v12)
- Lucide React icons
