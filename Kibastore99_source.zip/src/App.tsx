import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { loginWithGoogle, logoutUser } from './firebase';
import { db } from './firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import Navigation, { Page } from './components/Navigation';
import Toast from './components/Toast';
import { useToast } from './hooks/useToast';
import CartDrawer from './components/CartDrawer';

import Home from './pages/Home';
import ViaLogin from './pages/ViaLogin';
import ViaInMail from './pages/ViaInMail';
import SkinGifting from './pages/SkinGifting';
import BuyAccounts from './pages/BuyAccounts';
import AccountsPage from './pages/AccountsPage';
import SettingsPage from './pages/SettingsPage';
import OwnerPanel from './pages/OwnerPanel';

import { LogIn, LogOut, Sun, Moon, ShoppingCart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AvatarWithBorder from './components/AvatarWithBorder';
import ProfileModal, { loadProfile } from './components/ProfileModal';

interface StoreInfo {
  upiId: string;
  qrCodeUrl: string;
  paymentInstructions: string;
  whatsAppNumber: string;
}

function AppInner() {
  const { user, loading, isOwner } = useAuth();
  const { totalCount } = useCart();
  const [page, setPage] = useState<Page>('home');
  const [theme, setTheme] = useState<'dark' | 'light'>(() =>
    (localStorage.getItem('kiba-theme') as 'dark' | 'light') || 'dark'
  );
  const [storeInfo, setStoreInfo] = useState<StoreInfo>({
    whatsAppNumber: '919863068885',
    upiId: 'kebamimi1@oksbi',
    qrCodeUrl: 'https://i.imgur.com/QDS5t7c.png',
    paymentInstructions: '',
  });
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileKey, setProfileKey] = useState(0);
  const [cartOpen, setCartOpen] = useState(false);
  const { toasts, addToast, removeToast } = useToast();

  const profile = loadProfile(user?.photoURL || '', user?.displayName || '');

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'store'), (snap) => {
      if (snap.exists()) {
        const d = snap.data();
        setStoreInfo({
          whatsAppNumber: d.whatsAppNumber || '919863068885',
          upiId: d.upiId || 'kebamimi1@oksbi',
          qrCodeUrl: d.qrCodeUrl || 'https://i.imgur.com/QDS5t7c.png',
          paymentInstructions: d.paymentInstructions || '',
        });
      }
    }, () => {});
    return unsub;
  }, []);

  useEffect(() => {
    localStorage.setItem('kiba-theme', theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const handleToggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');

  const handleLogin = async () => {
    try {
      await loginWithGoogle();
    } catch (err: any) {
      const msg = err?.message || 'Login failed';
      if (msg.includes('unauthorized-domain')) {
        addToast('Domain not authorized in Firebase. Please add this domain to Firebase Auth settings.', 'error');
      } else {
        addToast('Login failed. Please try again.', 'error');
      }
    }
  };

  const navigate = (p: Page) => {
    if (p === 'owner' && !isOwner) return;
    setPage(p);
  };

  const isDark = theme === 'dark';

  const PAGE_TITLES: Record<Page, string> = {
    'home': 'Home',
    'via-login': 'Via Login',
    'via-inmail': 'Via In-Mail',
    'buy-accounts': 'Buy Accounts',
    'skin-gifting': 'Skin Gifting',
    'accounts': 'Accounts',
    'settings': 'Settings',
    'owner': 'Owner Panel',
  };

  return (
    <div className={`min-h-screen relative font-sans ${isDark ? 'bg-slate-950 text-slate-100 bg-grid-pattern' : 'bg-slate-50 text-slate-900'}`}>
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-amber-500/4 rounded-full blur-3xl -z-10 pointer-events-none" />
      <div className="fixed top-1/3 right-1/4 w-[500px] h-[500px] bg-amber-600/3 rounded-full blur-3xl -z-10 pointer-events-none" />

      <Navigation currentPage={page} onNavigate={navigate} />

      <div className="lg:pl-16 min-h-screen flex flex-col">
        <header className={`sticky top-0 z-30 border-b backdrop-blur-md ${isDark ? 'bg-slate-950/80 border-amber-500/10' : 'bg-white/80 border-slate-200 shadow-sm'}`}>
          <div className="flex items-center justify-between h-16 px-4 max-w-5xl mx-auto">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg overflow-hidden border border-amber-500/40 shrink-0 lg:hidden">
                <img src="https://i.imgur.com/q2oRMUK.jpeg" alt="Kiba" className="w-full h-full object-cover" />
              </div>
              <div>
                {page === 'home' ? (
                  <img
                    src="https://i.imgur.com/Tcy7dej.png"
                    alt="Kiba Official"
                    className="h-8 object-contain"
                    onError={e => { (e.currentTarget as HTMLImageElement).style.display='none'; }}
                  />
                ) : (
                  <h1 className={`font-display font-black text-base uppercase tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {PAGE_TITLES[page]}
                  </h1>
                )}
                <span className="text-[9px] text-amber-500 font-mono tracking-widest font-bold hidden sm:block">
                  💎 KIBA OFFICIAL
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCartOpen(true)}
                className={`relative p-2 rounded-xl border transition-all ${isDark ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-amber-400' : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-amber-600'}`}
              >
                <ShoppingCart size={16} />
                {totalCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-amber-500 text-slate-950 text-[10px] font-black rounded-full flex items-center justify-center animate-bounce">
                    {totalCount}
                  </span>
                )}
              </button>

              <button
                onClick={handleToggleTheme}
                className={`p-2 rounded-xl border transition-all ${isDark ? 'bg-slate-900 border-slate-800 text-amber-400' : 'bg-slate-100 border-slate-200 text-amber-600'}`}
              >
                {isDark ? <Sun size={15} /> : <Moon size={15} />}
              </button>

              {loading ? (
                <span className="text-[10px] font-mono text-slate-500">…</span>
              ) : user ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setProfileOpen(true)}
                    className="relative group focus:outline-none"
                    title="Edit Profile"
                  >
                    <AvatarWithBorder
                      key={profileKey}
                      avatarUrl={profile.avatarUrl || user.photoURL || ''}
                      borderId={profile.borderId}
                      size="md"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 bg-amber-500 text-slate-950 rounded-full w-4 h-4 flex items-center justify-center text-[8px] font-black opacity-0 group-hover:opacity-100 transition-opacity">✎</span>
                  </button>
                  {isOwner && (
                    <span className="hidden sm:block text-[10px] bg-amber-500 text-slate-950 font-black px-2 py-0.5 rounded-full uppercase">SBO</span>
                  )}
                  <button
                    onClick={logoutUser}
                    className={`p-2 rounded-xl border transition-all ${isDark ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-rose-400' : 'bg-slate-100 border-slate-200 text-slate-500 hover:text-rose-600'}`}
                  >
                    <LogOut size={14} />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleLogin}
                  className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase rounded-xl transition-all hover:scale-105"
                >
                  <LogIn size={14} />
                  Sign In
                </button>
              )}
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-6 pb-24 lg:pb-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
            >
              {page === 'home'         && <Home onNavigate={navigate} />}
              {page === 'via-login'    && <ViaLogin storeInfo={storeInfo} />}
              {page === 'via-inmail'   && <ViaInMail storeInfo={storeInfo} />}
              {page === 'skin-gifting' && <SkinGifting whatsAppNumber={storeInfo.whatsAppNumber} />}
              {page === 'buy-accounts' && <BuyAccounts whatsAppNumber={storeInfo.whatsAppNumber} />}
              {page === 'accounts'     && <AccountsPage />}
              {page === 'settings'     && <SettingsPage theme={theme} onToggleTheme={handleToggleTheme} whatsAppNumber={storeInfo.whatsAppNumber} />}
              {page === 'owner'        && (isOwner ? <OwnerPanel /> : (
                <div className="text-center py-16">
                  <p className="text-slate-400">Access restricted to owner only.</p>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </main>

        <footer className={`border-t py-4 px-4 text-center text-[10px] font-mono text-slate-500 ${isDark ? 'border-slate-900' : 'border-slate-200'}`}>
          © 2026 Kiba Official · MLBB Diamond Top-Up · <span className="text-amber-500">+{storeInfo.whatsAppNumber}</span>
        </footer>
      </div>

      <Toast toasts={toasts} onRemove={removeToast} />
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} storeInfo={storeInfo} />

      {user && (
        <ProfileModal
          open={profileOpen}
          onClose={() => { setProfileOpen(false); setProfileKey(k => k + 1); }}
          googlePhotoURL={user.photoURL || ''}
          googleDisplayName={user.displayName || ''}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppInner />
      </CartProvider>
    </AuthProvider>
  );
}
