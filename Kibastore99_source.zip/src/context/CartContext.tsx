import React, { createContext, useContext, useState, useEffect } from 'react';
import { DiamondPackage } from '../types';

export interface CartItem {
  pkg: DiamondPackage;
  type: 'login' | 'inmail';
  qty: number;
}

interface CartCtx {
  items: CartItem[];
  addItem: (pkg: DiamondPackage, type: 'login' | 'inmail') => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
  totalCount: number;
}

const CartContext = createContext<CartCtx>({
  items: [], addItem: () => {}, removeItem: () => {}, clearCart: () => {}, totalCount: 0,
});

const KEY = 'kiba-cart';

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
  });

  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(items)); }, [items]);

  const addItem = (pkg: DiamondPackage, type: 'login' | 'inmail') => {
    setItems(prev => {
      const exists = prev.find(i => i.pkg.id === pkg.id);
      if (exists) return prev.map(i => i.pkg.id === pkg.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { pkg, type, qty: 1 }];
    });
  };

  const removeItem = (id: string) => setItems(prev => prev.filter(i => i.pkg.id !== id));
  const clearCart = () => setItems([]);
  const totalCount = items.reduce((s, i) => s + i.qty, 0);

  return (
    <CartContext.Provider value={{ items, addItem, removeItem, clearCart, totalCount }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
