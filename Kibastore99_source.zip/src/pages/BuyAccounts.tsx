import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { AccountItem } from '../types';
import { Gamepad2, MessageCircle, Swords, Shirt } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  whatsAppNumber: string;
}

function buildWhatsAppUrl(account: AccountItem, phone: string) {
  const msg = `🎮 KIBA OFFICIAL - Account Purchase\n\nAccount: ${account.title}\nRank: ${account.rank}\nPrice: ${account.price}\nHeroes: ${account.heroCount} | Skins: ${account.skinCount}\n\nI'm interested in buying this account. Please share more details.`;
  return `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;
}

export default function BuyAccounts({ whatsAppNumber }: Props) {
  const [accounts, setAccounts] = useState<AccountItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'accounts'), orderBy('order', 'asc'));
    const unsub = onSnapshot(q, (snap) => {
      setAccounts(snap.docs.map(d => ({ id: d.id, ...d.data() } as AccountItem)));
      setLoading(false);
    }, () => setLoading(false));
    return () => unsub();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-5 rounded-2xl border border-amber-500/20 bg-slate-900/60">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <Gamepad2 size={22} />
        </div>
        <div>
          <h1 className="font-display font-black text-white text-xl uppercase tracking-tight">
            Buy Accounts 🎮
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">Premium MLBB accounts · Instant transfer</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-80 rounded-2xl bg-slate-800/50 animate-pulse" />
          ))}
        </div>
      ) : accounts.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <Gamepad2 size={48} className="mx-auto mb-4 opacity-30" />
          <p className="font-display font-bold text-lg uppercase">No accounts listed yet</p>
          <p className="text-sm mt-1">Check back soon or contact us on WhatsApp</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {accounts.map((account, i) => (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`relative rounded-2xl border overflow-hidden ${account.soldOut ? 'border-slate-700 opacity-60' : 'border-slate-800 hover:border-amber-500/40'} bg-slate-900 transition-all`}
            >
              <div className="bg-slate-800 relative flex items-center justify-center" style={{ aspectRatio: '16/9' }}>
                {account.imageUrl ? (
                  <img src={account.imageUrl} alt={account.title} className="w-full h-full object-contain" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Gamepad2 size={48} className="text-slate-600" />
                  </div>
                )}
                <div className="absolute top-3 right-3 bg-amber-500 text-slate-950 font-mono font-black text-sm px-3 py-1.5 rounded-xl shadow-lg">
                  {account.price}
                </div>
                {account.soldOut && (
                  <div className="absolute inset-0 bg-slate-950/70 flex items-center justify-center">
                    <span className="font-black font-display text-rose-400 text-xl uppercase border-2 border-rose-400 px-4 py-2 rounded-xl rotate-[-10deg]">
                      SOLD OUT
                    </span>
                  </div>
                )}
              </div>
              <div className="p-4 space-y-3">
                <div>
                  <h3 className="font-display font-black text-white text-base">{account.title}</h3>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="text-[10px] font-mono font-bold bg-amber-950/40 text-amber-400 border border-amber-900/50 px-2 py-0.5 rounded-full uppercase">
                      {account.rank}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                      <Swords size={10} /> {account.heroCount} Heroes
                    </span>
                    <span className="flex items-center gap-1 text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                      <Shirt size={10} /> {account.skinCount} Skins
                    </span>
                  </div>
                </div>
                {account.description && (
                  <p className="text-xs text-slate-400 leading-relaxed">{account.description}</p>
                )}
                {!account.soldOut && (
                  <a
                    href={buildWhatsAppUrl(account, whatsAppNumber)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all"
                  >
                    <MessageCircle size={15} />
                    Contact to Buy
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <a
        href={`https://wa.me/${whatsAppNumber.replace(/\D/g, '')}`}
        target="_blank"
        rel="noreferrer"
        className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black font-display uppercase tracking-wider transition-all"
      >
        <MessageCircle size={20} />
        Contact Us on WhatsApp
      </a>
    </div>
  );
}
