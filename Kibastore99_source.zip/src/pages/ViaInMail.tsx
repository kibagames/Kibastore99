import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { DiamondPackage } from '../types';
import DiamondCard from '../components/DiamondCard';
import DiamondCheckoutModal from '../components/DiamondCheckoutModal';
import { Mail, Calendar } from 'lucide-react';
import { AnimatePresence } from 'motion/react';

const DIAMOND_IMG = 'https://i.imgur.com/34jMRi2.png';

const DEFAULT_PACKAGES: Omit<DiamondPackage, 'id'>[] = [
  { diamonds: '8,000 Diamonds',  price: '₹5,000',  outOfStock: false, type: 'inmail', order: 0 },
  { diamonds: '10,000 Diamonds', price: '₹6,000',  outOfStock: false, type: 'inmail', order: 1 },
  { diamonds: '11,000 Diamonds', price: '₹7,000',  outOfStock: false, type: 'inmail', order: 2 },
  { diamonds: '12,500 Diamonds', price: '₹8,000',  outOfStock: false, type: 'inmail', order: 3 },
  { diamonds: '14,000 Diamonds', price: '₹9,000',  outOfStock: false, type: 'inmail', order: 4 },
  { diamonds: '17,500 Diamonds', price: '₹10,000', outOfStock: false, type: 'inmail', order: 5 },
  { diamonds: '20,000 Diamonds', price: '₹13,000', outOfStock: false, type: 'inmail', order: 6 },
  { diamonds: '26,000 Diamonds', price: '₹19,500', outOfStock: false, type: 'inmail', order: 7 },
  { diamonds: '30,000 Diamonds', price: '₹21,000', outOfStock: false, type: 'inmail', order: 8 },
  { diamonds: '40,000 Diamonds', price: '₹23,500', outOfStock: false, type: 'inmail', order: 9 },
  { diamonds: '50,000 Diamonds', price: '₹26,000', outOfStock: false, type: 'inmail', order: 10 },
  { diamonds: '60,000 Diamonds', price: '₹30,000', outOfStock: false, type: 'inmail', order: 11 },
  { diamonds: '70,000 Diamonds', price: '₹35,000', outOfStock: false, type: 'inmail', order: 12 },
];

interface StoreInfo {
  upiId: string;
  qrCodeUrl: string;
  paymentInstructions: string;
  whatsAppNumber: string;
}

interface Props {
  storeInfo: StoreInfo;
}

export default function ViaInMail({ storeInfo }: Props) {
  const [packages, setPackages] = useState<DiamondPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPkg, setSelectedPkg] = useState<DiamondPackage | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'viaInMailPackages'), orderBy('order', 'asc'));
    const unsub = onSnapshot(q, async (snap) => {
      if (snap.empty) {
        for (const pkg of DEFAULT_PACKAGES) {
          const ref = doc(collection(db, 'viaInMailPackages'));
          await setDoc(ref, { ...pkg, createdAt: serverTimestamp() }).catch(() => {});
        }
        setPackages(DEFAULT_PACKAGES.map((p, i) => ({ ...p, id: `default-${i}` })));
      } else {
        setPackages(snap.docs.map(d => ({ id: d.id, ...d.data() } as DiamondPackage)));
      }
      setLoading(false);
    }, () => {
      setPackages(DEFAULT_PACKAGES.map((p, i) => ({ ...p, id: `default-${i}` })));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-5 rounded-2xl border border-amber-500/20 bg-slate-900/60">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <Mail size={22} />
        </div>
        <div>
          <h1 className="font-display font-black text-white text-xl uppercase tracking-tight">
            MLBB In-Mail Diamonds 🔥
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">In-game mail delivery · All servers · Tap a package to order</p>
        </div>
      </div>

      <div className="flex items-start gap-3 p-4 rounded-2xl border border-amber-500/20 bg-amber-950/10">
        <Calendar size={18} className="text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed">
          <span className="text-amber-400 font-bold block mb-1">Expected Delivery Notice</span>
          Diamonds delivered via in-game mail. Expected arrival: <strong className="text-white">last week of July</strong>.
          Not eligible for recharge/top-up events.
        </div>
      </div>

      <div className="border border-slate-800 rounded-3xl p-5 bg-slate-950/60">
        <div className="flex items-center gap-3 mb-5">
          <img src={DIAMOND_IMG} alt="diamonds" className="w-8 h-8 object-contain" />
          <h2 className="font-display font-black text-amber-400 text-lg uppercase">In-Mail Packages</h2>
          <span className="ml-auto text-[10px] text-slate-500 font-mono">Tap any to buy</span>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-[74px] rounded-2xl bg-slate-800/50 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {packages.map(pkg => (
              <DiamondCard key={pkg.id} pkg={pkg} type="inmail" onSelect={setSelectedPkg} />
            ))}
          </div>
        )}
      </div>

      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/40 space-y-2.5">
        <h3 className="font-display font-bold text-amber-400 text-sm uppercase">📋 Required Details</h3>
        {[
          'MLBB ID + Server ID + Moonton Email required',
          'Diamonds delivered via in-game mail only',
          'Not eligible for recharge/top-up events',
          'Available for all servers worldwide',
        ].map((note, i) => (
          <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
            <span className="text-amber-500 shrink-0 mt-0.5">•</span>
            {note}
          </div>
        ))}
      </div>

      <AnimatePresence>
        {selectedPkg && (
          <DiamondCheckoutModal
            pkg={selectedPkg}
            type="inmail"
            storeInfo={storeInfo}
            onClose={() => setSelectedPkg(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
