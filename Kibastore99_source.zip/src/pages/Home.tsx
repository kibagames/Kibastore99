import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { BannerSlide } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Zap, Shield, MessageCircle, Gem, Star, Clock, X, LogIn, Mail, Shirt, Gamepad2 } from 'lucide-react';

const DEFAULT_BANNERS: BannerSlide[] = [
  {
    id: 'default-1',
    imageUrl: '',
    title: 'CHEAPEST MLBB DIAMONDS',
    description: 'India\'s #1 trusted MLBB top-up store. Fast delivery, 100% genuine.',
    buttonText: 'Shop Now',
    buttonLink: '',
  },
];

interface Props {
  onNavigate: (page: any) => void;
}

const SHOP_OPTIONS = [
  {
    page: 'via-login',
    icon: <LogIn size={22} />,
    label: 'Via Login',
    desc: 'Share your Moonton credentials — we log in and top-up directly.',
    badge: 'Fastest',
    badgeColor: 'bg-amber-500 text-slate-950',
    detail: 'From ₹1,900',
  },
  {
    page: 'via-inmail',
    icon: <Mail size={22} />,
    label: 'Via In-Mail',
    desc: 'Diamonds delivered straight to your in-game mailbox, no login needed.',
    badge: 'No Password',
    badgeColor: 'bg-sky-500 text-white',
    detail: 'From ₹5,000',
  },
  {
    page: 'skin-gifting',
    icon: <Shirt size={22} />,
    label: 'Skin Gifting',
    desc: 'Buy premium MLBB skins — gifted directly to your account.',
    badge: 'Popular',
    badgeColor: 'bg-fuchsia-500 text-white',
    detail: 'All servers',
  },
  {
    page: 'buy-accounts',
    icon: <Gamepad2 size={22} />,
    label: 'Buy Accounts',
    desc: 'Pre-built premium MLBB accounts with heroes, skins & high rank.',
    badge: 'Best Value',
    badgeColor: 'bg-emerald-600 text-white',
    detail: 'Instant transfer',
  },
];

export default function Home({ onNavigate }: Props) {
  const [banners, setBanners] = useState<BannerSlide[]>(DEFAULT_BANNERS);
  const [current, setCurrent] = useState(0);
  const [shopOpen, setShopOpen] = useState(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    const q = query(collection(db, 'banners'), orderBy('order', 'asc'));
    const unsub = onSnapshot(q, (snap) => {
      const slides = snap.docs.map(d => ({ id: d.id, ...d.data() } as BannerSlide));
      if (slides.length > 0) setBanners(slides);
    }, () => {});
    return () => unsub();
  }, []);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setCurrent(c => (c + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timerRef.current);
  }, [banners.length]);

  const prev = () => { clearInterval(timerRef.current); setCurrent(c => (c - 1 + banners.length) % banners.length); };
  const next = () => { clearInterval(timerRef.current); setCurrent(c => (c + 1) % banners.length); };

  const slide = banners[current];

  const features = [
    { icon: <Zap size={18} />, label: 'Instant Delivery', sub: '10–120 mins' },
    { icon: <Shield size={18} />, label: '100% Genuine', sub: 'Moonton verified' },
    { icon: <MessageCircle size={18} />, label: '24/7 Support', sub: 'WhatsApp chat' },
    { icon: <Star size={18} />, label: 'Lowest Prices', sub: 'Market best rates' },
  ];

  const handleBannerBtn = () => {
    if (slide.buttonLink) {
      window.open(slide.buttonLink, '_blank');
    } else {
      setShopOpen(true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-3xl border border-amber-500/20 bg-slate-900" style={{ aspectRatio: '16/9', maxHeight: '56vw' }}>
        <AnimatePresence mode="wait">
          <motion.div
            key={slide.id}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.4 }}
            className="absolute inset-0"
          >
            {slide.imageUrl ? (
              <img src={slide.imageUrl} alt={slide.title} className="w-full h-full object-contain bg-slate-900" />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-slate-900 via-amber-950/30 to-slate-950 flex items-center justify-center">
                <Gem size={80} className="text-amber-500/30" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/50 to-transparent" />
            <div className="absolute inset-0 flex flex-col justify-center px-8 py-8">
              <span className="text-[10px] font-mono font-black text-amber-400 uppercase tracking-widest mb-2">🔥 Kiba Official</span>
              <h2 className="font-display font-black text-2xl sm:text-4xl text-white uppercase tracking-tight leading-tight max-w-sm">
                {slide.title}
              </h2>
              {slide.description && (
                <p className="text-slate-300 text-sm mt-2 max-w-xs leading-relaxed">{slide.description}</p>
              )}
              {slide.buttonText && (
                <button
                  onClick={handleBannerBtn}
                  className="mt-4 self-start px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black font-display text-sm uppercase rounded-xl transition-all hover:scale-105"
                >
                  {slide.buttonText} →
                </button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {banners.length > 1 && (
          <>
            <button onClick={prev} className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-slate-950/60 text-white hover:bg-slate-950/80 transition-all">
              <ChevronLeft size={18} />
            </button>
            <button onClick={next} className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-slate-950/60 text-white hover:bg-slate-950/80 transition-all">
              <ChevronRight size={18} />
            </button>
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {banners.map((_, i) => (
                <button key={i} onClick={() => setCurrent(i)} className={`h-1.5 rounded-full transition-all ${i === current ? 'w-6 bg-amber-400' : 'w-1.5 bg-slate-600'}`} />
              ))}
            </div>
          </>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {features.map((f, i) => (
          <div
            key={i}
            className="flex items-center gap-3 p-3.5 rounded-2xl border border-slate-800 bg-slate-900/50 hover:border-amber-500/40 hover:bg-slate-900 transition-all text-left"
          >
            <span className="text-amber-400 shrink-0">{f.icon}</span>
            <div>
              <div className="text-xs font-bold text-white">{f.label}</div>
              <div className="text-[10px] text-slate-400 font-mono">{f.sub}</div>
            </div>
          </div>
        ))}
      </div>

      <div>
        <h3 className="font-display font-black text-white text-lg uppercase mb-4">Quick Shop</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {SHOP_OPTIONS.map((item) => (
            <button
              key={item.page}
              onClick={() => onNavigate(item.page as any)}
              className="flex items-start gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/50 hover:border-amber-500/40 hover:bg-slate-900 transition-all text-left group"
            >
              <div className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-amber-400 shrink-0 group-hover:border-amber-500/40 transition-all">
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <div className="font-display font-black text-white text-base group-hover:text-amber-400 transition-colors">{item.label}</div>
                  <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase ${item.badgeColor}`}>{item.badge}</span>
                </div>
                <div className="text-xs text-slate-400 leading-relaxed">{item.desc}</div>
                <div className="text-[11px] text-amber-500/80 font-mono font-bold mt-1">{item.detail} →</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/40 flex items-center gap-3">
        <Clock size={18} className="text-amber-400 shrink-0" />
        <p className="text-xs text-slate-300 leading-relaxed">
          <span className="text-amber-400 font-bold">Processing hours:</span> Evening to Midnight. Orders placed outside hours are processed next evening.
        </p>
      </div>

      <AnimatePresence>
        {shopOpen && (
          <div className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center bg-slate-950/90 backdrop-blur-md p-0 sm:p-4">
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
              className="w-full sm:max-w-md bg-[#0b0f1a] border-t sm:border border-amber-500/20 sm:rounded-3xl rounded-t-3xl overflow-hidden shadow-2xl"
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
                <div>
                  <h2 className="font-display font-black text-white text-lg uppercase">What do you want?</h2>
                  <p className="text-[10px] text-slate-400 font-mono">Select a service to continue</p>
                </div>
                <button onClick={() => setShopOpen(false)} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
                  <X size={18} />
                </button>
              </div>
              <div className="p-4 space-y-2.5">
                {SHOP_OPTIONS.map((opt) => (
                  <button
                    key={opt.page}
                    onClick={() => { setShopOpen(false); onNavigate(opt.page as any); }}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl border border-slate-800 hover:border-amber-500/40 bg-slate-900/60 hover:bg-slate-800/80 transition-all text-left group"
                  >
                    <div className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-amber-400 shrink-0 group-hover:border-amber-500/40 transition-all">
                      {opt.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-display font-black text-white text-base group-hover:text-amber-400 transition-colors">{opt.label}</span>
                        <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase ${opt.badgeColor}`}>{opt.badge}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">{opt.desc}</div>
                    </div>
                    <ChevronRight size={16} className="text-slate-600 group-hover:text-amber-400 shrink-0" />
                  </button>
                ))}
              </div>
              <div className="px-5 pb-5">
                <button onClick={() => setShopOpen(false)} className="w-full py-3 rounded-xl border border-slate-700 text-slate-400 hover:text-white font-bold text-sm transition-all">
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
