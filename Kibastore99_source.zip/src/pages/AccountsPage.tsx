import React from 'react';
import { useAuth } from '../context/AuthContext';
import { logoutUser } from '../firebase';
import { User, LogOut, Heart, ClipboardList, Edit3 } from 'lucide-react';
import AvatarWithBorder from '../components/AvatarWithBorder';
import { loadProfile } from '../components/ProfileModal';

const BG_VIDEO = 'https://www.image2url.com/r2/default/videos/1780107980614-20a4dfab-0f14-4da3-bb5f-bb566ccb6ec4.mp4';

export default function AccountsPage() {
  const { user } = useAuth();
  const profile = user ? loadProfile(user.photoURL || '', user.displayName || '') : null;

  if (!user) {
    return (
      <div className="text-center py-16 space-y-4">
        <User size={56} className="mx-auto text-slate-600" />
        <h2 className="font-display font-black text-white text-xl uppercase">Sign In Required</h2>
        <p className="text-slate-400 text-sm">Sign in with Google to access your account dashboard.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="rounded-3xl overflow-hidden border border-slate-800 bg-slate-900 relative">
        <video
          src={BG_VIDEO}
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(15,23,42,0.15) 0%, rgba(15,23,42,0.4) 40%, rgba(15,23,42,0.85) 65%, #0f172a 85%)' }} />

        <button
          onClick={logoutUser}
          className="absolute top-3 right-3 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950/70 backdrop-blur-sm border border-slate-700/60 text-slate-300 hover:text-rose-400 hover:border-rose-500/40 text-xs font-bold transition-all"
        >
          <LogOut size={12} />
          Sign Out
        </button>

        <div className="relative pt-32 sm:pt-44 px-5 pb-5">
          <div className="flex items-end gap-4">
            <div className="shrink-0 drop-shadow-[0_4px_16px_rgba(0,0,0,0.6)]">
              <AvatarWithBorder
                avatarUrl={profile?.avatarUrl || user.photoURL || ''}
                borderId={profile?.borderId || 'default'}
                size="xl"
              />
            </div>
            <div className="flex-1 min-w-0 pb-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-display font-black text-white text-xl leading-tight truncate">
                  {profile?.gamerTag || user.displayName || 'Player'}
                </h2>
                <span className="text-[10px] bg-amber-500/10 border border-amber-500/30 text-amber-400 px-2 py-0.5 rounded-full font-mono font-bold uppercase shrink-0">
                  MLBB
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 truncate">{user.email}</p>
              {profile?.mlbbUid && (
                <p className="text-[11px] text-slate-500 font-mono mt-1">
                  ID: <span className="text-amber-400/80">{profile.mlbbUid}</span>
                  {profile.serverId && <span> · Server: <span className="text-amber-400/80">{profile.serverId}</span></span>}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mt-4">
            {[
              { label: 'Gamer Tag', value: profile?.gamerTag || user.displayName || '—' },
              { label: 'MLBB ID', value: profile?.mlbbUid || '—' },
              { label: 'Server', value: profile?.serverId || '—' },
            ].map(({ label, value }) => (
              <div key={label} className="bg-slate-800/60 rounded-2xl p-3 text-center border border-slate-700/50">
                <div className="text-[9px] text-slate-500 font-mono uppercase mb-1">{label}</div>
                <div className="text-xs font-black text-white truncate">{value}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center gap-2 p-3 rounded-xl bg-amber-950/20 border border-amber-500/20">
            <Edit3 size={13} className="text-amber-400 shrink-0" />
            <p className="text-[11px] text-amber-300/80">Tap your avatar in the top bar to edit profile, borders, and MLBB details.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {[
          { icon: <ClipboardList size={22} />, title: 'Order History', desc: 'Your past orders are processed via WhatsApp. Contact us to track your order status.', color: 'text-amber-400', bg: 'bg-amber-500/5 border-amber-500/10' },
          { icon: <Heart size={22} />, title: 'Saved Profiles', desc: 'Favourite player profiles you\'ve searched will appear here (stored locally).', color: 'text-rose-400', bg: 'bg-rose-500/5 border-rose-500/10' },
        ].map((item, i) => (
          <div key={i} className={`flex items-start gap-4 p-4 rounded-2xl border ${item.bg}`}>
            <span className={`${item.color} mt-0.5 shrink-0`}>{item.icon}</span>
            <div>
              <h3 className="font-display font-bold text-white text-base">{item.title}</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
