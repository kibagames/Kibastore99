import React from 'react';
import { Settings, Moon, Sun, MessageCircle, Info } from 'lucide-react';

interface Props {
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  whatsAppNumber: string;
}

export default function SettingsPage({ theme, onToggleTheme, whatsAppNumber }: Props) {
  const isDark = theme === 'dark';

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-5 rounded-2xl border border-amber-500/20 bg-slate-900/60">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <Settings size={22} />
        </div>
        <div>
          <h1 className="font-display font-black text-white text-xl uppercase">Settings</h1>
          <p className="text-xs text-slate-400 mt-0.5">App preferences</p>
        </div>
      </div>

      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/50 space-y-3">
        <h3 className="font-display font-bold text-white text-sm uppercase text-amber-400">Appearance</h3>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isDark ? <Moon size={18} className="text-slate-400" /> : <Sun size={18} className="text-amber-400" />}
            <div>
              <div className="text-sm font-bold text-white">{isDark ? 'Dark Mode' : 'Light Mode'}</div>
              <div className="text-xs text-slate-400">Classic gaming aesthetic</div>
            </div>
          </div>
          <button
            onClick={onToggleTheme}
            className={`relative w-12 h-6 rounded-full transition-all ${isDark ? 'bg-amber-500' : 'bg-slate-600'}`}
          >
            <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${isDark ? 'left-6' : 'left-0.5'}`} />
          </button>
        </div>
      </div>

      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/50 space-y-3">
        <h3 className="font-display font-bold text-amber-400 text-sm uppercase">Support</h3>
        <a
          href={`https://wa.me/${whatsAppNumber.replace(/\D/g, '')}`}
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-3 p-3 rounded-xl bg-emerald-900/20 border border-emerald-800/40 hover:bg-emerald-900/30 transition-all"
        >
          <MessageCircle size={18} className="text-emerald-400" />
          <div>
            <div className="text-sm font-bold text-white">WhatsApp Support</div>
            <div className="text-xs text-slate-400">+{whatsAppNumber}</div>
          </div>
        </a>
      </div>

      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/50 space-y-2">
        <h3 className="font-display font-bold text-amber-400 text-sm uppercase flex items-center gap-2">
          <Info size={16} /> About
        </h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          Kiba Official Store is India's trusted MLBB diamond top-up store. We offer the cheapest prices, fastest delivery, and 100% genuine Moonton diamonds.
        </p>
        <p className="text-[10px] text-slate-600 font-mono">© 2026 Kiba Official. All rights reserved.</p>
      </div>
    </div>
  );
}
