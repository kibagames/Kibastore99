import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { DiamondPackage } from '../types';
import DiamondCard from '../components/DiamondCard';
import DiamondCheckoutModal from '../components/DiamondCheckoutModal';
import { LogIn, Shield, Globe } from 'lucide-react';
import { AnimatePresence } from 'motion/react';

const DIAMOND_IMG = 'https://i.imgur.com/34jMRi2.png';

const DEFAULT_PACKAGES: Omit<DiamondPackage, 'id'>[] = [
  { diamonds: '1765 Diamonds',  price: '₹1,900', outOfStock: false, type: 'login', order: 0 },
  { diamonds: '2920 Diamonds',  price: '₹2,950', outOfStock: false, type: 'login', order: 1 },
  { diamonds: '3530 Diamonds',  price: '₹3,600', outOfStock: false, type: 'login', order: 2 },
  { diamonds: '4685 Diamonds',  price: '₹4,650', outOfStock: false, type: 'login', order: 3 },
  { diamonds: '5295 Diamonds',  price: '₹5,250', outOfStock: false, type: 'login', order: 4 },
  { diamonds: '6450 Diamonds',  price: '₹6,300', outOfStock: false, type: 'login', order: 5 },
  { diamonds: '7060 Diamonds',  price: '₹7,000', outOfStock: false, type: 'login', order: 6 },
  { diamonds: '10590 Diamonds', price: '₹9,700', outOfStock: false, type: 'login', order: 7 },
];

interface StoreInfo {
  upiId: string;
  qrCodeUrl: string;
  paymentInstructions: string;
  whatsAppNumber: string;
}

interface Props {
  storeInfo: StoreInfo;
}

export default function ViaLogin({ storeInfo }: Props) {
  const [packages, setPackages] = useState<DiamondPackage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPkg, setSelectedPkg] = useState<DiamondPackage | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'viaLoginPackages'), orderBy('order', 'asc'));
    const unsub = onSnapshot(q, async (snap) => {
      if (snap.empty) {
        for (const pkg of DEFAULT_PACKAGES) {
          const ref = doc(collection(db, 'viaLoginPackages'));
          await setDoc(ref, { ...pkg, createdAt: serverTimestamp() }).catch(() => {});
        }
        setPackages(DEFAULT_PACKAGES.map((p, i) => ({ ...p, id: `default-${i}` })));
      } else {
        setPackages(snap.docs.map(d => ({ id: d.id, ...d.data() } as DiamondPackage)));
      }
      setLoading(false);
    }, () => {
      setPackages(DEFAULT_PACKAGES.map((p, i) => ({ ...p, id: `default-${i}` })));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-5 rounded-2xl border border-amber-500/20 bg-slate-900/60">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <LogIn size={22} />
        </div>
        <div>
          <h1 className="font-display font-black text-white text-xl uppercase tracking-tight">
            MLBB Via Login Diamonds 🔥
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">Login-based top-up · All servers supported · Tap a package to order</p>
        </div>
      </div>

      <div className="border border-slate-800 rounded-3xl p-5 bg-slate-950/60">
        <div className="flex items-center gap-3 mb-5">
          <img src={DIAMOND_IMG} alt="diamonds" className="w-8 h-8 object-contain" />
          <h2 className="font-display font-black text-amber-400 text-lg uppercase">Diamond Packages</h2>
          <span className="ml-auto text-[10px] text-slate-500 font-mono">Tap any to buy</span>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-[74px] rounded-2xl bg-slate-800/50 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {packages.map(pkg => (
              <DiamondCard key={pkg.id} pkg={pkg} type="login" onSelect={setSelectedPkg} />
            ))}
          </div>
        )}
      </div>

      <div className="p-5 rounded-2xl border border-slate-800 bg-slate-900/40 space-y-2.5">
        <h3 className="font-display font-bold text-amber-400 text-sm uppercase">📋 Important Notes</h3>
        {[
          'Requires Moonton account credentials (shared securely with delivery team only)',
          'Available for all servers worldwide',
          'Follow all game policies and requirements',
          'Contact support before ordering if unsure',
        ].map((note, i) => (
          <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
            <span className="text-amber-500 shrink-0 mt-0.5">•</span>
            {note}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center gap-2.5 p-3 rounded-xl border border-slate-800 bg-slate-900/40">
          <Globe size={16} className="text-amber-400" />
          <div>
            <div className="text-[10px] text-slate-400 font-mono uppercase">All Regions</div>
            <div className="text-xs font-bold text-white">Working ✓</div>
          </div>
        </div>
        <div className="flex items-center gap-2.5 p-3 rounded-xl border border-slate-800 bg-slate-900/40">
          <Shield size={16} className="text-amber-400" />
          <div>
            <div className="text-[10px] text-slate-400 font-mono uppercase">Security</div>
            <div className="text-xs font-bold text-white">100% Safe</div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {selectedPkg && (
          <DiamondCheckoutModal
            pkg={selectedPkg}
            type="login"
            storeInfo={storeInfo}
            onClose={() => setSelectedPkg(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
