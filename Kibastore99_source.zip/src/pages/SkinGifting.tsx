import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { SkinItem } from '../types';
import { Shirt, MessageCircle, ShoppingBag } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  whatsAppNumber: string;
}

function buildWhatsAppUrl(skin: SkinItem, phone: string) {
  const msg = `🎁 KIBA OFFICIAL - Skin Gifting Order\n\nSkin: ${skin.name}\nHero: ${skin.hero}\nPrice: ${skin.price}\n\nPlease share your:\n• MLBB ID\n• Server ID\n• IGN`;
  return `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;
}

export default function SkinGifting({ whatsAppNumber }: Props) {
  const [skins, setSkins] = useState<SkinItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'skins'), orderBy('order', 'asc'));
    const unsub = onSnapshot(q, (snap) => {
      setSkins(snap.docs.map(d => ({ id: d.id, ...d.data() } as SkinItem)));
      setLoading(false);
    }, () => setLoading(false));
    return () => unsub();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-5 rounded-2xl border border-amber-500/20 bg-slate-900/60">
        <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <Shirt size={22} />
        </div>
        <div>
          <h1 className="font-display font-black text-white text-xl uppercase tracking-tight">
            Skin Gifting 🎁
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">Premium MLBB skins · Gifted directly to your account</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-64 rounded-2xl bg-slate-800/50 animate-pulse" />
          ))}
        </div>
      ) : skins.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <Shirt size={48} className="mx-auto mb-4 opacity-30" />
          <p className="font-display font-bold text-lg uppercase">No skins listed yet</p>
          <p className="text-sm mt-1">Check back soon or contact us on WhatsApp</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {skins.map((skin, i) => (
            <motion.div
              key={skin.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`relative rounded-2xl border overflow-hidden ${skin.soldOut ? 'border-slate-700 opacity-60' : 'border-slate-800 hover:border-amber-500/40'} bg-slate-900 transition-all`}
            >
              <div className="bg-slate-800 relative flex items-center justify-center" style={{ aspectRatio: '16/9' }}>
                {skin.imageUrl ? (
                  <img src={skin.imageUrl} alt={skin.name} className="w-full h-full object-contain" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Shirt size={48} className="text-slate-600" />
                  </div>
                )}
                {skin.soldOut && (
                  <div className="absolute inset-0 bg-slate-950/70 flex items-center justify-center">
                    <span className="font-black font-display text-rose-400 text-xl uppercase border-2 border-rose-400 px-4 py-2 rounded-xl rotate-[-10deg]">
                      SOLD OUT
                    </span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-display font-black text-white text-base">{skin.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Hero: {skin.hero}</p>
                  </div>
                  <span className="font-mono font-black text-amber-400 text-lg shrink-0">{skin.price}</span>
                </div>
                {skin.description && (
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">{skin.description}</p>
                )}
                {!skin.soldOut && (
                  <a
                    href={buildWhatsAppUrl(skin, whatsAppNumber)}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all"
                  >
                    <ShoppingBag size={15} />
                    Buy Now
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <a
        href={`https://wa.me/${whatsAppNumber.replace(/\D/g, '')}`}
        target="_blank"
        rel="noreferrer"
        className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black font-display uppercase tracking-wider transition-all hover:scale-[1.02]"
      >
        <MessageCircle size={20} />
        Enquire on WhatsApp
      </a>
    </div>
  );
}
