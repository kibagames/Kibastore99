import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection, doc, setDoc, updateDoc, deleteDoc,
  onSnapshot, query, orderBy, serverTimestamp, addDoc
} from 'firebase/firestore';
import {
  DiamondPackage, SkinItem, AccountItem, BannerSlide, StoreSettings
} from '../types';
import {
  Shield, Plus, Trash2, Edit3, Save, X, ToggleLeft, ToggleRight,
  Gem, Shirt, Gamepad2, Settings, Layout, AlertTriangle, Copy, Check, Search
} from 'lucide-react';
import { useToast } from '../hooks/useToast';
import Toast from '../components/Toast';

function getFirebaseError(err: any): string {
  const code = err?.code || '';
  const msg = (err?.message || '').toLowerCase();
  if (code === 'permission-denied' || msg.includes('permission') || msg.includes('missing or insufficient')) {
    return 'Permission denied — Firestore rules not set up. See the "Firebase Setup" section at the top of this panel.';
  }
  if (code === 'unauthenticated' || msg.includes('unauthenticated')) {
    return 'You must be signed in as the owner to save changes.';
  }
  return `Save failed: ${err?.message || 'Unknown error'}`;
}

type Section = 'banners' | 'login-packages' | 'inmail-packages' | 'skins' | 'accounts' | 'settings' | 'mlbb-checker';

const SECTIONS: { id: Section; label: string; icon: React.ReactNode }[] = [
  { id: 'banners',          label: 'Banner Manager',    icon: <Layout size={18} /> },
  { id: 'login-packages',   label: 'Via Login Prices',  icon: <Gem size={18} /> },
  { id: 'inmail-packages',  label: 'In-Mail Prices',    icon: <Gem size={18} /> },
  { id: 'skins',            label: 'Skin Gifting',      icon: <Shirt size={18} /> },
  { id: 'accounts',         label: 'Accounts',          icon: <Gamepad2 size={18} /> },
  { id: 'mlbb-checker',     label: 'ID Checker',        icon: <Search size={18} /> },
  { id: 'settings',         label: 'Store Settings',    icon: <Settings size={18} /> },
];

function Input({ label, value, onChange, placeholder = '', type = 'text', textarea = false }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string; textarea?: boolean;
}) {
  const cls = "w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-500";
  return (
    <label className="block space-y-1.5">
      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">{label}</span>
      {textarea
        ? <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={3} className={cls + ' resize-none'} />
        : <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className={cls} />
      }
    </label>
  );
}

function BannerManager() {
  const [banners, setBanners] = useState<BannerSlide[]>([]);
  const [editing, setEditing] = useState<BannerSlide | null>(null);
  const [isNew, setIsNew] = useState(false);
  const { toasts, addToast, removeToast } = useToast();

  useEffect(() => {
    const q = query(collection(db, 'banners'), orderBy('order', 'asc'));
    return onSnapshot(q, snap => setBanners(snap.docs.map(d => ({ id: d.id, ...d.data() } as BannerSlide))), () => {});
  }, []);

  const startNew = () => {
    setEditing({ id: '', imageUrl: '', title: '', description: '', buttonText: 'Shop Now', buttonLink: '', order: banners.length });
    setIsNew(true);
  };

  const startEdit = (b: BannerSlide) => { setEditing({ ...b }); setIsNew(false); };

  const save = async () => {
    if (!editing) return;
    try {
      if (isNew) {
        const { id: _id, ...rest } = editing;
        await addDoc(collection(db, 'banners'), { ...rest, createdAt: serverTimestamp() });
      } else {
        const { id, ...rest } = editing;
        await updateDoc(doc(db, 'banners', id), { ...rest, updatedAt: serverTimestamp() });
      }
      addToast('Banner saved!', 'success');
      setEditing(null);
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this banner?')) return;
    try {
      await deleteDoc(doc(db, 'banners', id));
      addToast('Banner deleted', 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  return (
    <div className="space-y-4">
      <Toast toasts={toasts} onRemove={removeToast} />
      <div className="flex justify-end">
        <button onClick={startNew} className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm rounded-xl transition-all">
          <Plus size={16} /> Add Banner
        </button>
      </div>

      {editing && (
        <div className="p-5 rounded-2xl border border-amber-500/30 bg-slate-900/80 space-y-4">
          <h4 className="font-display font-black text-amber-400 uppercase">{isNew ? 'New Banner' : 'Edit Banner'}</h4>
          <Input label="Image URL" value={editing.imageUrl} onChange={v => setEditing(e => e && ({ ...e, imageUrl: v }))} placeholder="https://..." />
          {editing.imageUrl && (
            <img src={editing.imageUrl} alt="preview" className="w-full max-h-32 object-cover rounded-xl border border-slate-700" onError={e => (e.currentTarget.style.display = 'none')} />
          )}
          <Input label="Title" value={editing.title} onChange={v => setEditing(e => e && ({ ...e, title: v }))} placeholder="CHEAPEST MLBB DIAMONDS" />
          <Input label="Description" value={editing.description} onChange={v => setEditing(e => e && ({ ...e, description: v }))} textarea placeholder="Short description..." />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Button Text" value={editing.buttonText} onChange={v => setEditing(e => e && ({ ...e, buttonText: v }))} placeholder="Shop Now" />
            <Input label="Button Link" value={editing.buttonLink} onChange={v => setEditing(e => e && ({ ...e, buttonLink: v }))} placeholder="https://..." />
          </div>
          <div className="flex gap-2">
            <button onClick={save} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl flex-1 justify-center">
              <Save size={15} /> Save
            </button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-xl">
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {banners.length === 0 && !editing && (
          <p className="text-sm text-slate-500 text-center py-8">No banners yet. Click "Add Banner" to create one.</p>
        )}
        {banners.map(b => (
          <div key={b.id} className="flex items-center gap-3 p-4 rounded-2xl border border-slate-800 bg-slate-900/50">
            {b.imageUrl && <img src={b.imageUrl} alt="" className="w-16 h-10 object-cover rounded-lg border border-slate-700 shrink-0" onError={e => (e.currentTarget.style.display = 'none')} />}
            <div className="flex-1 min-w-0">
              <div className="font-bold text-white text-sm truncate">{b.title || '(No title)'}</div>
              <div className="text-xs text-slate-400 truncate">{b.description}</div>
            </div>
            <div className="flex gap-2 shrink-0">
              <button onClick={() => startEdit(b)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400"><Edit3 size={14} /></button>
              <button onClick={() => remove(b.id)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DiamondManager({ collectionName }: { collectionName: string }) {
  const [packages, setPackages] = useState<DiamondPackage[]>([]);
  const [editing, setEditing] = useState<DiamondPackage | null>(null);
  const [isNew, setIsNew] = useState(false);
  const { toasts, addToast, removeToast } = useToast();
  const type = collectionName === 'viaLoginPackages' ? 'login' : 'inmail';

  useEffect(() => {
    const q = query(collection(db, collectionName), orderBy('order', 'asc'));
    return onSnapshot(q, snap => setPackages(snap.docs.map(d => ({ id: d.id, ...d.data() } as DiamondPackage))), () => {});
  }, [collectionName]);

  const startNew = () => {
    setEditing({ id: '', diamonds: '', price: '', outOfStock: false, type, order: packages.length });
    setIsNew(true);
  };

  const startEdit = (p: DiamondPackage) => { setEditing({ ...p }); setIsNew(false); };

  const save = async () => {
    if (!editing) return;
    try {
      if (isNew) {
        const { id: _id, ...rest } = editing;
        await addDoc(collection(db, collectionName), { ...rest, createdAt: serverTimestamp() });
      } else {
        const { id, ...rest } = editing;
        await updateDoc(doc(db, collectionName, id), { ...rest, updatedAt: serverTimestamp() });
      }
      addToast('Package saved!', 'success');
      setEditing(null);
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const toggleStock = async (pkg: DiamondPackage) => {
    try {
      await updateDoc(doc(db, collectionName, pkg.id), { outOfStock: !pkg.outOfStock });
      addToast(`Marked as ${pkg.outOfStock ? 'available' : 'out of stock'}`, 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this package?')) return;
    try {
      await deleteDoc(doc(db, collectionName, id));
      addToast('Deleted', 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  return (
    <div className="space-y-4">
      <Toast toasts={toasts} onRemove={removeToast} />
      <div className="flex justify-end">
        <button onClick={startNew} className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm rounded-xl">
          <Plus size={16} /> Add Package
        </button>
      </div>

      {editing && (
        <div className="p-5 rounded-2xl border border-amber-500/30 bg-slate-900/80 space-y-4">
          <h4 className="font-display font-black text-amber-400 uppercase">{isNew ? 'New Package' : 'Edit Package'}</h4>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Diamonds" value={editing.diamonds} onChange={v => setEditing(e => e && ({ ...e, diamonds: v }))} placeholder="1765 Diamonds" />
            <Input label="Price" value={editing.price} onChange={v => setEditing(e => e && ({ ...e, price: v }))} placeholder="₹1,900" />
          </div>
          <div className="flex gap-2">
            <button onClick={save} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl flex-1 justify-center">
              <Save size={15} /> Save
            </button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-xl">
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {packages.map(pkg => (
          <div key={pkg.id} className={`flex items-center gap-3 p-3 rounded-xl border ${pkg.outOfStock ? 'border-slate-700 opacity-60' : 'border-slate-800'} bg-slate-900/50`}>
            <div className="flex-1">
              <span className="font-bold text-white text-sm">{pkg.diamonds}</span>
              <span className="text-amber-400 font-mono ml-3">{pkg.price}</span>
              {pkg.outOfStock && <span className="ml-2 text-[10px] text-rose-400 font-bold uppercase">Out of Stock</span>}
            </div>
            <div className="flex gap-1.5 shrink-0">
              <button onClick={() => toggleStock(pkg)} title={pkg.outOfStock ? 'Mark available' : 'Mark out of stock'} className={`p-1.5 rounded-lg transition-all ${pkg.outOfStock ? 'bg-rose-900/30 text-rose-400 hover:bg-rose-900/50' : 'bg-emerald-900/30 text-emerald-400 hover:bg-emerald-900/50'}`}>
                {pkg.outOfStock ? <ToggleLeft size={16} /> : <ToggleRight size={16} />}
              </button>
              <button onClick={() => startEdit(pkg)} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400"><Edit3 size={14} /></button>
              <button onClick={() => remove(pkg.id)} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SkinManager() {
  const [skins, setSkins] = useState<SkinItem[]>([]);
  const [editing, setEditing] = useState<SkinItem | null>(null);
  const [isNew, setIsNew] = useState(false);
  const { toasts, addToast, removeToast } = useToast();

  useEffect(() => {
    const q = query(collection(db, 'skins'), orderBy('order', 'asc'));
    return onSnapshot(q, snap => setSkins(snap.docs.map(d => ({ id: d.id, ...d.data() } as SkinItem))), () => {});
  }, []);

  const blank = (): SkinItem => ({ id: '', name: '', hero: '', price: '', imageUrl: '', description: '', soldOut: false, order: skins.length });

  const save = async () => {
    if (!editing) return;
    try {
      if (isNew) {
        const { id: _sid, ...skinRest } = editing;
        await addDoc(collection(db, 'skins'), { ...skinRest, createdAt: serverTimestamp() });
      } else {
        const { id, ...rest } = editing;
        await updateDoc(doc(db, 'skins', id), { ...rest, updatedAt: serverTimestamp() });
      }
      addToast('Skin saved!', 'success');
      setEditing(null);
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const toggleSold = async (skin: SkinItem) => {
    try {
      await updateDoc(doc(db, 'skins', skin.id), { soldOut: !skin.soldOut });
      addToast(`Marked as ${skin.soldOut ? 'available' : 'sold out'}`, 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this skin?')) return;
    try {
      await deleteDoc(doc(db, 'skins', id));
      addToast('Skin deleted', 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  return (
    <div className="space-y-4">
      <Toast toasts={toasts} onRemove={removeToast} />
      <div className="flex justify-end">
        <button onClick={() => { setEditing(blank()); setIsNew(true); }} className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm rounded-xl">
          <Plus size={16} /> Add Skin
        </button>
      </div>

      {editing && (
        <div className="p-5 rounded-2xl border border-amber-500/30 bg-slate-900/80 space-y-4">
          <h4 className="font-display font-black text-amber-400 uppercase">{isNew ? 'New Skin' : 'Edit Skin'}</h4>
          <Input label="Image URL" value={editing.imageUrl} onChange={v => setEditing(e => e && ({ ...e, imageUrl: v }))} placeholder="https://..." />
          {editing.imageUrl && (
            <img src={editing.imageUrl} alt="preview" className="w-full max-h-40 object-cover rounded-xl border border-slate-700" onError={e => (e.currentTarget.style.display = 'none')} />
          )}
          <div className="grid grid-cols-2 gap-3">
            <Input label="Skin Name" value={editing.name} onChange={v => setEditing(e => e && ({ ...e, name: v }))} placeholder="Fallen Blood" />
            <Input label="Hero" value={editing.hero} onChange={v => setEditing(e => e && ({ ...e, hero: v }))} placeholder="Alucard" />
          </div>
          <Input label="Price" value={editing.price} onChange={v => setEditing(e => e && ({ ...e, price: v }))} placeholder="₹999" />
          <Input label="Description" value={editing.description} onChange={v => setEditing(e => e && ({ ...e, description: v }))} textarea placeholder="Skin description..." />
          <div className="flex gap-2">
            <button onClick={save} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl flex-1 justify-center">
              <Save size={15} /> Save
            </button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-xl">
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {skins.map(skin => (
          <div key={skin.id} className={`flex items-center gap-3 p-3 rounded-xl border ${skin.soldOut ? 'border-slate-700 opacity-60' : 'border-slate-800'} bg-slate-900/50`}>
            {skin.imageUrl && <img src={skin.imageUrl} alt="" className="w-12 h-12 object-cover rounded-lg shrink-0" onError={e => (e.currentTarget.style.display = 'none')} />}
            <div className="flex-1 min-w-0">
              <div className="font-bold text-white text-sm truncate">{skin.name}</div>
              <div className="text-xs text-slate-400">{skin.hero} · {skin.price}</div>
              {skin.soldOut && <span className="text-[10px] text-rose-400 font-bold uppercase">Sold Out</span>}
            </div>
            <div className="flex gap-1.5 shrink-0">
              <button onClick={() => toggleSold(skin)} className={`p-1.5 rounded-lg transition-all ${skin.soldOut ? 'bg-rose-900/30 text-rose-400' : 'bg-emerald-900/30 text-emerald-400'}`}>
                {skin.soldOut ? <ToggleLeft size={16} /> : <ToggleRight size={16} />}
              </button>
              <button onClick={() => { setEditing({ ...skin }); setIsNew(false); }} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400"><Edit3 size={14} /></button>
              <button onClick={() => remove(skin.id)} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
        {skins.length === 0 && <p className="text-sm text-slate-500 text-center py-6">No skins yet.</p>}
      </div>
    </div>
  );
}

function AccountManager() {
  const [accounts, setAccounts] = useState<AccountItem[]>([]);
  const [editing, setEditing] = useState<AccountItem | null>(null);
  const [isNew, setIsNew] = useState(false);
  const { toasts, addToast, removeToast } = useToast();

  useEffect(() => {
    const q = query(collection(db, 'accounts'), orderBy('order', 'asc'));
    return onSnapshot(q, snap => setAccounts(snap.docs.map(d => ({ id: d.id, ...d.data() } as AccountItem))), () => {});
  }, []);

  const blank = (): AccountItem => ({ id: '', title: '', price: '', rank: '', heroCount: '', skinCount: '', description: '', imageUrl: '', soldOut: false, order: accounts.length });

  const save = async () => {
    if (!editing) return;
    try {
      if (isNew) {
        const { id: _aid, ...accRest } = editing;
        await addDoc(collection(db, 'accounts'), { ...accRest, createdAt: serverTimestamp() });
      } else {
        const { id, ...rest } = editing;
        await updateDoc(doc(db, 'accounts', id), { ...rest, updatedAt: serverTimestamp() });
      }
      addToast('Account saved!', 'success');
      setEditing(null);
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const toggleSold = async (acc: AccountItem) => {
    try {
      await updateDoc(doc(db, 'accounts', acc.id), { soldOut: !acc.soldOut });
      addToast(`Marked as ${acc.soldOut ? 'available' : 'sold out'}`, 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this account listing?')) return;
    try {
      await deleteDoc(doc(db, 'accounts', id));
      addToast('Account deleted', 'info');
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  return (
    <div className="space-y-4">
      <Toast toasts={toasts} onRemove={removeToast} />
      <div className="flex justify-end">
        <button onClick={() => { setEditing(blank()); setIsNew(true); }} className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm rounded-xl">
          <Plus size={16} /> Add Account
        </button>
      </div>

      {editing && (
        <div className="p-5 rounded-2xl border border-amber-500/30 bg-slate-900/80 space-y-4">
          <h4 className="font-display font-black text-amber-400 uppercase">{isNew ? 'New Account' : 'Edit Account'}</h4>
          <Input label="Image URL" value={editing.imageUrl} onChange={v => setEditing(e => e && ({ ...e, imageUrl: v }))} placeholder="https://..." />
          {editing.imageUrl && (
            <img src={editing.imageUrl} alt="preview" className="w-full max-h-40 object-cover rounded-xl border border-slate-700" onError={e => (e.currentTarget.style.display = 'none')} />
          )}
          <Input label="Title" value={editing.title} onChange={v => setEditing(e => e && ({ ...e, title: v }))} placeholder="Mythical Glory Account" />
          <Input label="Price" value={editing.price} onChange={v => setEditing(e => e && ({ ...e, price: v }))} placeholder="₹15,000" />
          <div className="grid grid-cols-3 gap-3">
            <Input label="Rank" value={editing.rank} onChange={v => setEditing(e => e && ({ ...e, rank: v }))} placeholder="Mythic" />
            <Input label="Heroes" value={editing.heroCount} onChange={v => setEditing(e => e && ({ ...e, heroCount: v }))} placeholder="100" />
            <Input label="Skins" value={editing.skinCount} onChange={v => setEditing(e => e && ({ ...e, skinCount: v }))} placeholder="50" />
          </div>
          <Input label="Description" value={editing.description} onChange={v => setEditing(e => e && ({ ...e, description: v }))} textarea placeholder="Account details..." />
          <div className="flex gap-2">
            <button onClick={save} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl flex-1 justify-center">
              <Save size={15} /> Save
            </button>
            <button onClick={() => setEditing(null)} className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm rounded-xl">
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {accounts.map(acc => (
          <div key={acc.id} className={`flex items-center gap-3 p-3 rounded-xl border ${acc.soldOut ? 'border-slate-700 opacity-60' : 'border-slate-800'} bg-slate-900/50`}>
            {acc.imageUrl && <img src={acc.imageUrl} alt="" className="w-14 h-10 object-cover rounded-lg shrink-0" onError={e => (e.currentTarget.style.display = 'none')} />}
            <div className="flex-1 min-w-0">
              <div className="font-bold text-white text-sm truncate">{acc.title}</div>
              <div className="text-xs text-slate-400">{acc.rank} · {acc.price}</div>
              {acc.soldOut && <span className="text-[10px] text-rose-400 font-bold uppercase">Sold Out</span>}
            </div>
            <div className="flex gap-1.5 shrink-0">
              <button onClick={() => toggleSold(acc)} className={`p-1.5 rounded-lg transition-all ${acc.soldOut ? 'bg-rose-900/30 text-rose-400' : 'bg-emerald-900/30 text-emerald-400'}`}>
                {acc.soldOut ? <ToggleLeft size={16} /> : <ToggleRight size={16} />}
              </button>
              <button onClick={() => { setEditing({ ...acc }); setIsNew(false); }} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400"><Edit3 size={14} /></button>
              <button onClick={() => remove(acc.id)} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-400"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
        {accounts.length === 0 && <p className="text-sm text-slate-500 text-center py-6">No accounts yet.</p>}
      </div>
    </div>
  );
}

function StoreSettingsPanel() {
  const [settings, setSettings] = useState<StoreSettings>({
    storeName: 'Kiba Official Store',
    whatsAppNumber: '919863068885',
    paymentInstructions: 'Pay via UPI and share the UTR number.',
    paymentMethods: 'UPI, PhonePe, GPay, Paytm',
    qrCodeUrl: 'https://i.imgur.com/QDS5t7c.png',
    upiId: 'kebamimi1@oksbi',
  });
  const [saved, setSaved] = useState(false);
  const { toasts, addToast, removeToast } = useToast();

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'store'), (snap) => {
      if (snap.exists()) setSettings(s => ({ ...s, ...snap.data() }));
    }, () => {});
    return unsub;
  }, []);

  const save = async () => {
    try {
      await setDoc(doc(db, 'settings', 'store'), { ...settings, updatedAt: serverTimestamp() }, { merge: true });
      addToast('Settings saved!', 'success');
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) { addToast(getFirebaseError(err), 'error'); }
  };

  return (
    <div className="space-y-4">
      <Toast toasts={toasts} onRemove={removeToast} />
      <Input label="Store Name" value={settings.storeName} onChange={v => setSettings(s => ({ ...s, storeName: v }))} placeholder="Kiba Official Store" />
      <Input label="WhatsApp Number (with country code)" value={settings.whatsAppNumber} onChange={v => setSettings(s => ({ ...s, whatsAppNumber: v }))} placeholder="919863068885" />
      <Input label="UPI ID" value={settings.upiId} onChange={v => setSettings(s => ({ ...s, upiId: v }))} placeholder="kiba@upi" />
      <Input label="QR Code Image URL" value={settings.qrCodeUrl} onChange={v => setSettings(s => ({ ...s, qrCodeUrl: v }))} placeholder="https://..." />
      {settings.qrCodeUrl && <img src={settings.qrCodeUrl} alt="QR" className="w-40 h-40 object-contain rounded-xl border border-slate-700" onError={e => (e.currentTarget.style.display = 'none')} />}
      <Input label="Payment Methods" value={settings.paymentMethods} onChange={v => setSettings(s => ({ ...s, paymentMethods: v }))} placeholder="UPI, PhonePe, GPay" />
      <Input label="Payment Instructions" value={settings.paymentInstructions} onChange={v => setSettings(s => ({ ...s, paymentInstructions: v }))} textarea placeholder="Instruct customers how to pay..." />
      <button onClick={save} className={`w-full py-3 rounded-xl font-black font-display uppercase text-sm transition-all flex items-center justify-center gap-2 ${saved ? 'bg-emerald-600 text-white' : 'bg-amber-500 hover:bg-amber-400 text-slate-950'}`}>
        <Save size={16} />
        {saved ? 'Saved!' : 'Save Settings'}
      </button>
    </div>
  );
}

const RULES_TEXT = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} { allow read: if true; }
    match /banners/{id} {
      allow write: if request.auth != null && request.auth.token.email == 'kebamimi1@gmail.com';
    }
    match /viaLoginPackages/{id} {
      allow write: if request.auth != null && request.auth.token.email == 'kebamimi1@gmail.com';
    }
    match /viaInMailPackages/{id} {
      allow write: if request.auth != null && request.auth.token.email == 'kebamimi1@gmail.com';
    }
    match /skins/{id} {
      allow write: if request.auth != null && request.auth.token.email == 'kebamimi1@gmail.com';
    }
    match /accounts/{id} {
      allow write: if request.auth != null && request.auth.token.email == 'kebamimi1@gmail.com';
    }
    match /settings/{id} {
      allow write: if request.auth != null && request.auth.token.email == 'kebamimi1@gmail.com';
    }
    match /orders/{id} { allow write: if request.auth != null; }
  }
}`;

function FirebaseSetupNotice() {
  const [copied, setCopied] = React.useState(false);
  const [open, setOpen] = React.useState(false);

  const copy = () => {
    navigator.clipboard.writeText(RULES_TEXT).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  return (
    <div className="rounded-2xl border border-amber-500/40 bg-amber-950/20 overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-amber-950/30 transition-all"
      >
        <AlertTriangle size={18} className="text-amber-400 shrink-0" />
        <div className="flex-1">
          <div className="font-bold text-amber-300 text-sm">Firebase Setup Required — Saving won't work until you do this</div>
          <div className="text-[10px] text-amber-500/70 font-mono mt-0.5">Click to expand setup instructions</div>
        </div>
        <span className="text-amber-400 text-xs">{open ? '▲' : '▼'}</span>
      </button>
      {open && (
        <div className="px-5 pb-5 space-y-3 border-t border-amber-500/20">
          <ol className="text-xs text-slate-300 space-y-1.5 pt-3">
            <li><span className="text-amber-400 font-bold">1.</span> Go to <a href="https://console.firebase.google.com/project/kiba-official/firestore/rules" target="_blank" rel="noreferrer" className="text-amber-400 underline">Firebase Console → Firestore → Rules</a></li>
            <li><span className="text-amber-400 font-bold">2.</span> Delete all existing rules and paste the rules below</li>
            <li><span className="text-amber-400 font-bold">3.</span> Click <b className="text-white">Publish</b> — done!</li>
          </ol>
          <div className="relative rounded-xl overflow-hidden border border-amber-900/40">
            <pre className="text-[10px] font-mono text-slate-300 bg-slate-950 p-3 overflow-x-auto whitespace-pre leading-5">{RULES_TEXT}</pre>
            <button
              onClick={copy}
              className={`absolute top-2 right-2 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all ${copied ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-amber-400'}`}
            >
              {copied ? <><Check size={11} /> Copied!</> : <><Copy size={11} /> Copy Rules</>}
            </button>
          </div>
          <p className="text-[10px] text-slate-500">Public read + owner-only write for kebamimi1@gmail.com.</p>
        </div>
      )}
    </div>
  );
}

function hashStr(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function generateProfile(uid: string, zoneId: string) {
  const seed = hashStr(uid + zoneId);
  const names = ['Shadow King', 'Dragon Slayer', 'Phantom X', 'Iron Fang', 'Storm Blade', 'Nova Edge', 'Crimson Wolf', 'Ghost Rider'];
  const regions = ['🇮🇳 India', '🇵🇭 Philippines', '🇮🇩 Indonesia', '🇲🇾 Malaysia', '🇸🇬 Singapore', '🇹🇭 Thailand'];
  const ranks = ['Mythical Glory', 'Mythic', 'Legend', 'Epic', 'Elite', 'Master'];
  return {
    ign:     names[seed % names.length],
    region:  regions[seed % regions.length],
    level:   30 + (seed % 70),
    rank:    ranks[seed % ranks.length],
    winRate: 45 + (seed % 40),
  };
}

function MLBBChecker() {
  const [uid, setUid] = useState('');
  const [zone, setZone] = useState('');
  const [profile, setProfile] = useState<ReturnType<typeof generateProfile> | null>(null);

  const check = () => {
    if (!uid.trim() || !zone.trim()) return;
    setProfile(generateProfile(uid.trim(), zone.trim()));
  };

  return (
    <div className="space-y-5">
      <p className="text-xs text-slate-400 leading-relaxed">
        Look up any MLBB player profile by Game ID and Zone ID. Use this to verify a customer's account before topping up.
      </p>
      <p className="text-[10px] text-slate-600 font-mono">⚠️ Demo tool — shows sample profile data for reference only</p>

      <div className="flex gap-2">
        <input
          value={uid}
          onChange={e => setUid(e.target.value)}
          placeholder="MLBB Game ID"
          className="flex-1 px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-500"
        />
        <input
          value={zone}
          onChange={e => setZone(e.target.value)}
          placeholder="Zone ID"
          className="w-28 px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-500"
        />
        <button
          onClick={check}
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm rounded-xl transition-all"
        >
          Check
        </button>
      </div>

      {profile && (
        <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-2.5 text-sm">
          {[
            { label: 'IGN', value: profile.ign },
            { label: 'Region', value: profile.region },
            { label: 'Level', value: String(profile.level) },
            { label: 'Rank', value: profile.rank, color: 'text-amber-400' },
            { label: 'Win Rate', value: `${profile.winRate}%`, color: 'text-emerald-400' },
          ].map(({ label, value, color }) => (
            <div key={label} className="flex justify-between items-center">
              <span className="text-slate-400">{label}</span>
              <span className={`font-bold ${color || 'text-white'}`}>{value}</span>
            </div>
          ))}
          <p className="text-[10px] text-slate-600 text-center pt-1">⚠️ Sample data only — not a live Moonton lookup</p>
        </div>
      )}
    </div>
  );
}

export default function OwnerPanel() {
  const [activeSection, setActiveSection] = useState<Section>('banners');

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-5 rounded-2xl border border-amber-500/30 bg-amber-950/10">
        <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
          <Shield size={22} />
        </div>
        <div>
          <h1 className="font-display font-black text-amber-400 text-xl uppercase">Owner Panel</h1>
          <p className="text-xs text-slate-400 mt-0.5">Admin-only · Manage everything live</p>
        </div>
      </div>

      <FirebaseSetupNotice />

      <div className="flex flex-wrap gap-2">
        {SECTIONS.map(s => (
          <button
            key={s.id}
            onClick={() => setActiveSection(s.id)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-bold transition-all ${
              activeSection === s.id
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-400'
                : 'border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
            }`}
          >
            {s.icon}
            <span className="hidden sm:inline">{s.label}</span>
          </button>
        ))}
      </div>

      <div className="border border-slate-800 rounded-2xl p-5 bg-slate-900/40">
        <h2 className="font-display font-black text-white text-base uppercase mb-5 pb-3 border-b border-slate-800">
          {SECTIONS.find(s => s.id === activeSection)?.label}
        </h2>

        {activeSection === 'banners'         && <BannerManager />}
        {activeSection === 'login-packages'  && <DiamondManager collectionName="viaLoginPackages" />}
        {activeSection === 'inmail-packages' && <DiamondManager collectionName="viaInMailPackages" />}
        {activeSection === 'skins'           && <SkinManager />}
        {activeSection === 'accounts'        && <AccountManager />}
        {activeSection === 'mlbb-checker'    && <MLBBChecker />}
        {activeSection === 'settings'        && <StoreSettingsPanel />}
      </div>
    </div>
  );
}
