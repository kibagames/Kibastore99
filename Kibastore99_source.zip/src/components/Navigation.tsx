import React from 'react';
import { Home, LogIn, Mail, ShoppingBag, Shirt, User, Settings, Shield, X, Menu } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';

export type Page = 'home' | 'via-login' | 'via-inmail' | 'buy-accounts' | 'skin-gifting' | 'accounts' | 'settings' | 'owner';

interface NavItem {
  id: Page;
  label: string;
  icon: React.ReactNode;
  ownerOnly?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home',        label: 'Home',        icon: <Home size={20} /> },
  { id: 'via-login',   label: 'Via Login',   icon: <LogIn size={20} /> },
  { id: 'via-inmail',  label: 'Via In-Mail', icon: <Mail size={20} /> },
  { id: 'buy-accounts',label: 'Buy Accounts',icon: <ShoppingBag size={20} /> },
  { id: 'skin-gifting',label: 'Skin Gifting',icon: <Shirt size={20} /> },
  { id: 'accounts',    label: 'Accounts',    icon: <User size={20} /> },
  { id: 'settings',    label: 'Settings',    icon: <Settings size={20} /> },
  { id: 'owner',       label: 'Owner Panel', icon: <Shield size={20} />, ownerOnly: true },
];

interface Props {
  currentPage: Page;
  onNavigate: (p: Page) => void;
}

export default function Navigation({ currentPage, onNavigate }: Props) {
  const { isOwner } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const visibleItems = NAV_ITEMS.filter(i => !i.ownerOnly || isOwner);
  const bottomItems = visibleItems.slice(0, 5);

  const handleNav = (p: Page) => {
    onNavigate(p);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <aside className="hidden lg:flex fixed left-0 top-0 h-full w-16 hover:w-56 group/sidebar z-40 transition-all duration-300 ease-in-out flex-col glass-dark border-r border-amber-500/10">
        <div className="h-16 flex items-center justify-center shrink-0 border-b border-amber-500/10 overflow-hidden">
          <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-slate-950 font-black text-sm shrink-0">
            KB
          </div>
          <span className="ml-3 font-display font-black text-white text-sm uppercase tracking-tight whitespace-nowrap opacity-0 group-hover/sidebar:opacity-100 transition-opacity duration-200">
            Kiba Official
          </span>
        </div>

        <nav className="flex-1 py-4 overflow-hidden">
          {visibleItems.map((item) => {
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-3 mb-1 rounded-xl mx-1.5 transition-all duration-200 text-left ${
                  active
                    ? item.id === 'owner'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-amber-500/15 text-amber-400 border border-amber-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border border-transparent'
                }`}
                style={{ width: 'calc(100% - 12px)' }}
              >
                <span className="shrink-0">{item.icon}</span>
                <span className="font-display font-semibold text-sm whitespace-nowrap opacity-0 group-hover/sidebar:opacity-100 transition-opacity duration-200">
                  {item.label}
                </span>
                {item.id === 'owner' && (
                  <span className="ml-auto text-[9px] bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded font-black uppercase opacity-0 group-hover/sidebar:opacity-100 transition-opacity duration-200">
                    ADMIN
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </aside>

      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 glass-dark border-t border-amber-500/10 pb-safe">
        <div className="flex items-center justify-around h-16 px-2">
          {bottomItems.map((item) => {
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`flex flex-col items-center justify-center gap-1 flex-1 h-full rounded-xl mx-0.5 transition-all ${
                  active ? 'text-amber-400' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {active && (
                  <span className="absolute top-0 w-8 h-0.5 bg-amber-400 rounded-full" style={{ position: 'relative', display: 'block', width: 32, height: 2, marginBottom: -2 }} />
                )}
                {item.icon}
                <span className="text-[9px] font-bold uppercase tracking-wide">{item.label.split(' ')[0]}</span>
              </button>
            );
          })}
          <button
            onClick={() => setMobileMenuOpen(true)}
            className="flex flex-col items-center justify-center gap-1 flex-1 h-full rounded-xl text-slate-500 hover:text-slate-300"
          >
            <Menu size={20} />
            <span className="text-[9px] font-bold uppercase tracking-wide">More</span>
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="lg:hidden fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col"
          >
            <div className="flex items-center justify-between px-6 pt-10 pb-6 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-slate-950 font-black text-sm">KB</div>
                <span className="font-display font-black text-white text-lg uppercase">Kiba Official</span>
              </div>
              <button onClick={() => setMobileMenuOpen(false)} className="p-2 text-slate-400 hover:text-white">
                <X size={22} />
              </button>
            </div>
            <div className="flex-1 p-6 space-y-2 overflow-y-auto">
              {visibleItems.map((item) => {
                const active = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNav(item.id)}
                    className={`w-full flex items-center gap-4 p-4 rounded-2xl border transition-all text-left ${
                      active
                        ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                        : 'border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <span>{item.icon}</span>
                    <span className="font-display font-semibold text-base">{item.label}</span>
                    {item.id === 'owner' && (
                      <span className="ml-auto text-[9px] bg-amber-500 text-slate-950 px-2 py-1 rounded font-black uppercase">ADMIN</span>
                    )}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
