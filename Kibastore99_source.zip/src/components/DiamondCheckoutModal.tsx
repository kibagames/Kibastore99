import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X, ShoppingCart, Zap, ChevronRight, ChevronLeft,
  Copy, Check, MessageCircle, User, Shield, Smartphone,
  Lock, CheckCircle2, AlertCircle, QrCode,
} from 'lucide-react';
import { DiamondPackage } from '../types';
import { useCart } from '../context/CartContext';

const DIAMOND_IMG = 'https://i.imgur.com/34jMRi2.png';

interface StoreInfo {
  upiId: string;
  qrCodeUrl: string;
  paymentInstructions: string;
  whatsAppNumber: string;
}

interface Props {
  pkg: DiamondPackage | null;
  type: 'login' | 'inmail';
  storeInfo: StoreInfo;
  onClose: () => void;
}

type Step = 'quick' | 'details' | 'payment' | 'done';

interface OrderDetails {
  mlbbUid: string;
  serverId: string;
  ign: string;
  montonEmail: string;
  password: string;
  utr: string;
  paymentConfirmed: boolean;
}

const EMPTY_ORDER: OrderDetails = {
  mlbbUid: '', serverId: '', ign: '', montonEmail: '', password: '', utr: '', paymentConfirmed: false,
};

function buildWhatsAppMessage(pkg: DiamondPackage, type: string, details: OrderDetails) {
  const method = type === 'login' ? 'Via Login' : 'Via In-Mail';
  const lines = [
    `💎 *KIBA OFFICIAL - Diamond Order*`,
    ``,
    `📦 *Package:* ${pkg.diamonds}`,
    `💰 *Price:* ${pkg.price}`,
    `🔧 *Method:* ${method}`,
    ``,
    `👤 *MLBB User ID:* ${details.mlbbUid}`,
    `🌐 *Server ID:* ${details.serverId}`,
    `🎮 *IGN:* ${details.ign}`,
    ...(type === 'login'
      ? [
          `📧 *Moonton Email:* ${details.montonEmail}`,
          `🔐 *Password:* ${details.password}`,
        ]
      : []),
    ``,
    `💳 *UTR / Transaction ID:* ${details.utr}`,
    ``,
    `✅ Payment confirmed by buyer.`,
  ];
  return lines.join('\n');
}

export default function DiamondCheckoutModal({ pkg, type, storeInfo, onClose }: Props) {
  const [step, setStep] = useState<Step>('quick');
  const [order, setOrder] = useState<OrderDetails>(EMPTY_ORDER);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [errors, setErrors] = useState<Partial<OrderDetails>>({});
  const { addItem } = useCart();

  if (!pkg) return null;

  const set = (k: keyof OrderDetails, v: string | boolean) =>
    setOrder(o => ({ ...o, [k]: v }));

  const copyUpi = () => {
    navigator.clipboard.writeText(storeInfo.upiId).then(() => {
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    });
  };

  const validateDetails = () => {
    const e: Partial<OrderDetails> = {};
    if (!order.mlbbUid.trim()) e.mlbbUid = 'Required';
    if (!order.serverId.trim()) e.serverId = 'Required';
    if (!order.ign.trim()) e.ign = 'Required';
    if (type === 'login' && !order.montonEmail.trim()) e.montonEmail = 'Required for Via Login';
    if (type === 'login' && !order.password.trim()) e.password = 'Required for Via Login';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validatePayment = () => {
    const e: Partial<OrderDetails> = {};
    if (!order.utr.trim()) e.utr = 'Enter UTR / Transaction ID';
    if (!order.paymentConfirmed) e.paymentConfirmed = 'Please confirm' as any;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleAddToCart = () => {
    addItem(pkg, type);
    onClose();
  };

  const handleBuyNow = () => {
    setStep('details');
    setErrors({});
  };

  const goToPayment = () => {
    if (validateDetails()) { setStep('payment'); setErrors({}); }
  };

  const submitOrder = () => {
    if (validatePayment()) setStep('done');
  };

  const openWhatsApp = () => {
    const msg = buildWhatsAppMessage(pkg, type, order);
    const url = `https://wa.me/${storeInfo.whatsAppNumber.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const STEPS: Step[] = ['quick', 'details', 'payment', 'done'];
  const stepIndex = STEPS.indexOf(step);

  return (
    <div className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center bg-slate-950/90 backdrop-blur-md p-0 sm:p-4">
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 60, opacity: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="w-full sm:max-w-md bg-[#0b0f1a] border-t sm:border border-amber-500/20 sm:rounded-3xl rounded-t-3xl overflow-hidden shadow-2xl flex flex-col max-h-[96vh] sm:max-h-[88vh]"
      >
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <img src={DIAMOND_IMG} className="w-8 h-8 object-contain" alt="" />
            <div>
              <div className="font-display font-black text-white text-base leading-tight">{pkg.diamonds} 💎</div>
              <div className="text-xs font-mono text-amber-400 font-bold">{pkg.price}</div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
            <X size={18} />
          </button>
        </div>

        {step !== 'quick' && (
          <div className="px-5 pt-4 pb-3 border-b border-slate-800 shrink-0">
            <div className="flex items-center justify-between">
              {['Details', 'Payment', 'Done'].map((label, i) => {
                const active = (step === 'details' && i === 0) || (step === 'payment' && i === 1) || (step === 'done' && i === 2);
                const done = (step === 'payment' && i === 0) || (step === 'done' && i <= 1);
                return (
                  <React.Fragment key={label}>
                    <div className="flex flex-col items-center gap-1">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black transition-all ${done ? 'bg-emerald-500 text-white' : active ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-500'}`}>
                        {done ? <Check size={14} /> : i + 1}
                      </div>
                      <span className={`text-[9px] font-mono uppercase font-bold ${active ? 'text-amber-400' : done ? 'text-emerald-400' : 'text-slate-600'}`}>{label}</span>
                    </div>
                    {i < 2 && <div className={`flex-1 h-0.5 mx-2 rounded-full ${done ? 'bg-emerald-500' : 'bg-slate-800'}`} />}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">

            {step === 'quick' && (
              <motion.div key="quick" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-5 space-y-5">
                <div className="rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-950/20 to-slate-900 p-5 flex items-center gap-4">
                  <div className="w-20 h-20 rounded-2xl bg-slate-950 border border-amber-500/30 flex items-center justify-center shrink-0">
                    <img src={DIAMOND_IMG} className="w-14 h-14 object-contain drop-shadow-[0_0_12px_rgba(245,158,11,0.5)]" alt="" />
                  </div>
                  <div>
                    <div className="font-display font-black text-white text-2xl leading-tight">{pkg.diamonds}</div>
                    <div className="text-sm text-slate-400 mt-0.5">{type === 'login' ? '⚙️ Via Login' : '📨 Via In-Mail'}</div>
                    <div className="text-amber-400 font-black text-xl font-mono mt-1">{pkg.price}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { icon: <Zap size={14} />, text: 'Instant Delivery' },
                    { icon: <Shield size={14} />, text: '100% Genuine' },
                    { icon: <CheckCircle2 size={14} />, text: 'Moonton Verified' },
                    { icon: <MessageCircle size={14} />, text: '24/7 Support' },
                  ].map(({ icon, text }) => (
                    <div key={text} className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
                      <span className="text-amber-400">{icon}</span>
                      {text}
                    </div>
                  ))}
                </div>

                <div className="space-y-3 pt-1">
                  <button
                    onClick={handleBuyNow}
                    className="w-full py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-base uppercase tracking-wide flex items-center justify-center gap-2.5 transition-all hover:scale-[1.02] shadow-lg shadow-amber-900/30"
                  >
                    <Zap size={18} />
                    Buy Now
                    <ChevronRight size={18} />
                  </button>
                  <button
                    onClick={handleAddToCart}
                    className="w-full py-3.5 rounded-2xl border border-slate-700 hover:border-amber-500/40 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm uppercase flex items-center justify-center gap-2 transition-all"
                  >
                    <ShoppingCart size={16} />
                    Add to Cart
                  </button>
                </div>
              </motion.div>
            )}

            {step === 'details' && (
              <motion.div key="details" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-5 space-y-5">
                <div>
                  <h3 className="font-display font-black text-white text-lg">Your Moonton Details</h3>
                  <p className="text-xs text-slate-400 mt-1">We need these to top-up your account correctly.</p>
                </div>

                <div className="space-y-3.5">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-slate-400 font-mono font-bold uppercase mb-1.5 flex items-center gap-1"><User size={10} /> MLBB User ID *</label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={order.mlbbUid}
                        onChange={e => set('mlbbUid', e.target.value)}
                        placeholder="e.g. 19582963"
                        className={`w-full px-3 py-2.5 rounded-xl bg-slate-800 border text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-600 ${errors.mlbbUid ? 'border-rose-500' : 'border-slate-700'}`}
                      />
                      {errors.mlbbUid && <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1"><AlertCircle size={10} />{errors.mlbbUid}</p>}
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 font-mono font-bold uppercase mb-1.5 flex items-center gap-1"><Shield size={10} /> Server ID *</label>
                      <input
                        type="number"
                        inputMode="numeric"
                        value={order.serverId}
                        onChange={e => set('serverId', e.target.value)}
                        placeholder="e.g. 2190"
                        className={`w-full px-3 py-2.5 rounded-xl bg-slate-800 border text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-600 ${errors.serverId ? 'border-rose-500' : 'border-slate-700'}`}
                      />
                      {errors.serverId && <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1"><AlertCircle size={10} />{errors.serverId}</p>}
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 font-mono font-bold uppercase mb-1.5 flex items-center gap-1"><Smartphone size={10} /> In-Game Name (IGN) *</label>
                    <input
                      type="text"
                      value={order.ign}
                      onChange={e => set('ign', e.target.value)}
                      placeholder="e.g. KIBA MASTER"
                      className={`w-full px-3 py-2.5 rounded-xl bg-slate-800 border text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-600 ${errors.ign ? 'border-rose-500' : 'border-slate-700'}`}
                    />
                    {errors.ign && <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1"><AlertCircle size={10} />{errors.ign}</p>}
                  </div>

                  {type === 'login' && (
                    <>
                      <div>
                        <label className="text-[10px] text-slate-400 font-mono font-bold uppercase mb-1.5 flex items-center gap-1"><Smartphone size={10} /> Moonton Email *</label>
                        <input
                          type="email"
                          value={order.montonEmail}
                          onChange={e => set('montonEmail', e.target.value)}
                          placeholder="e.g. player@gmail.com"
                          className={`w-full px-3 py-2.5 rounded-xl bg-slate-800 border text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-600 ${errors.montonEmail ? 'border-rose-500' : 'border-slate-700'}`}
                        />
                        {errors.montonEmail && <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1"><AlertCircle size={10} />{errors.montonEmail}</p>}
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 font-mono font-bold uppercase mb-1.5 flex items-center gap-1">
                          <Lock size={10} /> Account Password *
                          <span className="ml-auto text-amber-500/80 normal-case font-normal text-[9px]">Required for login top-up</span>
                        </label>
                        <input
                          type="password"
                          value={order.password}
                          onChange={e => set('password', e.target.value)}
                          placeholder="Your Moonton password"
                          className={`w-full px-3 py-2.5 rounded-xl bg-slate-800 border text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-600 ${errors.password ? 'border-rose-500' : 'border-slate-700'}`}
                        />
                        {errors.password && <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1"><AlertCircle size={10} />{errors.password}</p>}
                        <p className="text-[10px] text-slate-500 mt-1.5 flex items-center gap-1">
                          <Shield size={10} className="text-emerald-500 shrink-0" />
                          Shared only with our delivery team · Never stored or misused
                        </p>
                      </div>
                    </>
                  )}
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 space-y-1">
                  <div className="text-amber-400 font-bold text-[11px] uppercase">📍 How to find your ID?</div>
                  <div>Open MLBB → Profile → your <b className="text-white">User ID</b> and <b className="text-white">Server ID</b> are shown below your nickname.</div>
                </div>
              </motion.div>
            )}

            {step === 'payment' && (
              <motion.div key="payment" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-5 space-y-5">
                <div>
                  <h3 className="font-display font-black text-white text-lg">Make Payment</h3>
                  <p className="text-xs text-slate-400 mt-1">Pay <span className="text-amber-400 font-bold">{pkg.price}</span> and enter your UTR below.</p>
                </div>

                <div className="flex items-center justify-center py-4 rounded-2xl bg-amber-950/20 border border-amber-500/20">
                  <div className="text-center">
                    <div className="text-[11px] text-slate-400 font-mono uppercase">Total Amount</div>
                    <div className="font-display font-black text-amber-400 text-3xl mt-1">{pkg.price}</div>
                    <div className="text-[11px] text-slate-500 mt-1">{pkg.diamonds} · {type === 'login' ? 'Via Login' : 'Via In-Mail'}</div>
                  </div>
                </div>

                {storeInfo.qrCodeUrl ? (
                  <div className="flex flex-col items-center gap-3 p-4 rounded-2xl bg-white">
                    <img src={storeInfo.qrCodeUrl} alt="QR Code" className="w-44 h-44 object-contain" />
                    <p className="text-slate-800 text-xs font-bold">Scan with any UPI app</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2 p-6 rounded-2xl bg-slate-900 border border-slate-800 text-slate-500">
                    <QrCode size={40} className="opacity-40" />
                    <p className="text-xs">QR code not configured yet</p>
                  </div>
                )}

                {storeInfo.upiId && (
                  <div className="flex items-center gap-2 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                    <div className="flex-1 min-w-0">
                      <div className="text-[9px] font-mono font-bold text-slate-500 uppercase mb-0.5">UPI ID</div>
                      <div className="text-sm font-bold text-white truncate">{storeInfo.upiId}</div>
                    </div>
                    <button
                      onClick={copyUpi}
                      className={`shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all ${copiedUpi ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-amber-400'}`}
                    >
                      {copiedUpi ? <Check size={13} /> : <Copy size={13} />}
                      {copiedUpi ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                )}

                {storeInfo.paymentInstructions && (
                  <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-800/30 text-xs text-amber-200/80">
                    {storeInfo.paymentInstructions}
                  </div>
                )}

                <div>
                  <label className="text-[10px] text-slate-400 font-mono font-bold uppercase mb-1.5 flex items-center gap-1">
                    <CheckCircle2 size={10} /> UTR / Transaction Reference ID *
                  </label>
                  <input
                    type="text"
                    value={order.utr}
                    onChange={e => set('utr', e.target.value)}
                    placeholder="12-digit UTR or transaction ID"
                    className={`w-full px-3 py-2.5 rounded-xl bg-slate-800 border text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-600 ${errors.utr ? 'border-rose-500' : 'border-slate-700'}`}
                  />
                  {errors.utr && <p className="text-[10px] text-rose-400 mt-1 flex items-center gap-1"><AlertCircle size={10} />{errors.utr}</p>}
                </div>

                <label className="flex items-start gap-3 cursor-pointer">
                  <div
                    onClick={() => set('paymentConfirmed', !order.paymentConfirmed)}
                    className={`mt-0.5 w-5 h-5 shrink-0 rounded-md border-2 flex items-center justify-center transition-all ${order.paymentConfirmed ? 'bg-emerald-500 border-emerald-500' : errors.paymentConfirmed ? 'border-rose-500' : 'border-slate-600 bg-slate-800'}`}
                  >
                    {order.paymentConfirmed && <Check size={12} className="text-white" />}
                  </div>
                  <span className="text-xs text-slate-300 leading-relaxed">
                    I confirm I have paid <b className="text-amber-400">{pkg.price}</b> and the payment is successful. I understand the order will be processed after verification.
                  </span>
                </label>
                {errors.paymentConfirmed && <p className="text-[10px] text-rose-400 -mt-2 flex items-center gap-1"><AlertCircle size={10} />Please confirm your payment</p>}
              </motion.div>
            )}

            {step === 'done' && (
              <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="p-5 space-y-5">
                <div className="flex flex-col items-center text-center gap-3 py-4">
                  <div className="w-20 h-20 rounded-full bg-emerald-500/10 border-2 border-emerald-500/40 flex items-center justify-center">
                    <CheckCircle2 size={40} className="text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="font-display font-black text-white text-xl">Order Ready!</h3>
                    <p className="text-xs text-slate-400 mt-1">Now send us your order details on WhatsApp to complete the process.</p>
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden">
                  <div className="px-4 py-3 bg-slate-800/60 text-[10px] font-mono font-bold text-slate-400 uppercase">Order Summary</div>
                  {[
                    { label: 'Package', value: pkg.diamonds },
                    { label: 'Price', value: pkg.price },
                    { label: 'Method', value: type === 'login' ? 'Via Login' : 'Via In-Mail' },
                    { label: 'MLBB ID', value: order.mlbbUid },
                    { label: 'Server', value: order.serverId },
                    { label: 'IGN', value: order.ign },
                    ...(type === 'login' ? [
                      { label: 'Moonton Email', value: order.montonEmail },
                      { label: 'Password', value: '••••••••' },
                    ] : []),
                    { label: 'UTR', value: order.utr },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex justify-between items-center px-4 py-2.5 border-t border-slate-800/60 text-sm">
                      <span className="text-slate-400 text-xs">{label}</span>
                      <span className="text-white font-bold text-xs truncate max-w-[60%] text-right">{value}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={openWhatsApp}
                  className="w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-base uppercase flex items-center justify-center gap-2.5 transition-all hover:scale-[1.02] shadow-lg shadow-emerald-900/40"
                >
                  <MessageCircle size={20} />
                  Send Order on WhatsApp
                </button>

                <p className="text-center text-[11px] text-slate-500">
                  Opens WhatsApp with all your order details pre-filled · Reply time: 10–120 mins
                </p>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {(step === 'details' || step === 'payment') && (
          <div className="px-5 py-4 border-t border-slate-800 shrink-0 flex gap-3">
            <button
              onClick={() => { setStep(step === 'payment' ? 'details' : 'quick'); setErrors({}); }}
              className="flex items-center gap-1.5 px-4 py-3 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 font-bold text-sm transition-all"
            >
              <ChevronLeft size={16} /> Back
            </button>
            <button
              onClick={step === 'details' ? goToPayment : submitOrder}
              className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm uppercase flex items-center justify-center gap-2 transition-all"
            >
              {step === 'details' ? 'Continue to Payment' : 'Confirm Order'}
              <ChevronRight size={16} />
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
