import React from 'react';

export interface AvatarBorder {
  id: string;
  name: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legend' | 'Mythic' | 'Collector' | 'Special';
}

export const AVATAR_BORDERS: AvatarBorder[] = [
  { id: 'default',          name: 'Default',           rarity: 'Common'    },
  { id: 'amber-glow',       name: 'Amber Glow',        rarity: 'Rare'      },
  { id: 'mystic-phoenix',   name: 'Mystic Phoenix',    rarity: 'Legend'    },
  { id: 'glacier-ice',      name: 'Glacier Ice',       rarity: 'Epic'      },
  { id: 'cyber-laser',      name: 'Cyber Laser',       rarity: 'Epic'      },
  { id: 'cosmic-star',      name: 'Cosmic Star',       rarity: 'Legend'    },
  { id: 'legend-wings',     name: 'Legend Wings',      rarity: 'Legend'    },
  { id: 'mythic-immortal',  name: 'Mythic Immortal',   rarity: 'Mythic'    },
  { id: 'shadow-assassin',  name: 'Shadow Assassin',   rarity: 'Rare'      },
  { id: 'sakura-dream',     name: 'Sakura Dream',      rarity: 'Rare'      },
  { id: 'abysm-lord',       name: 'Abysm Lord',        rarity: 'Mythic'    },
  { id: 'star-guardian',    name: 'Star Guardian',     rarity: 'Epic'      },
  { id: 'dragon-soul',      name: 'Dragon Soul',       rarity: 'Legend'    },
  { id: 'arcade-matrix',    name: 'Arcade Matrix',     rarity: 'Special'   },
  { id: 'venom-pulse',      name: 'Venom Pulse',       rarity: 'Epic'      },
  { id: 'gold-champion',    name: 'Gold Champion',     rarity: 'Legend'    },
  { id: 'celestial-god',    name: 'Celestial God',     rarity: 'Collector' },
  { id: 'void-wanderer',    name: 'Void Wanderer',     rarity: 'Epic'      },
  { id: 'kiba-exclusive',   name: 'Kiba Exclusive',    rarity: 'Collector' },
  { id: 'neon-shogun',      name: 'Neon Shogun',       rarity: 'Legend'    },
  { id: 'emerald-aurora',   name: 'Emerald Aurora',    rarity: 'Rare'      },
  { id: 'super-saiyan',     name: 'Super Saiyan',      rarity: 'Mythic'    },
  { id: 'sharingan-eye',    name: 'Sharingan Eye',     rarity: 'Collector' },
  { id: 'water-breathing',  name: 'Water Breathing',   rarity: 'Special'   },
  { id: 'sun-god',          name: 'Sun God',           rarity: 'Mythic'    },
  { id: 'hollow-mask',      name: 'Hollow Mask',       rarity: 'Collector' },
  { id: 'shadow-sovereign', name: 'Shadow Sovereign',  rarity: 'Mythic'    },
  { id: 'domain-limitless', name: 'Domain Limitless',  rarity: 'Collector' },
  { id: 'curse-seal',       name: 'Curse Seal',        rarity: 'Special'   },
  { id: 'thunder-god',      name: 'Thunder God',       rarity: 'Legend'    },
];

function BorderFrame({ id }: { id: string }) {
  switch (id) {
    case 'amber-glow':
      return <div className="absolute inset-0 rounded-full border-2 border-amber-500 animate-pulse shadow-[0_0_10px_rgba(245,158,11,0.6)]" />;
    case 'mystic-phoenix':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-t-rose-500 border-r-orange-500 border-b-yellow-400 border-l-red-500 animate-spin" style={{ animationDuration: '3s' }} />
        <div className="absolute -inset-0.5 rounded-full bg-red-500/10 blur-[2px] animate-pulse" />
      </>;
    case 'glacier-ice':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.7)]" />
        <div className="absolute -top-1 -right-1 text-[8px] animate-bounce">❄</div>
      </>;
    case 'cyber-laser':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-pink-500 shadow-[0_0_12px_rgba(236,72,153,0.8)]" />
        <div className="absolute inset-1 rounded-full border border-teal-400 rotate-45 animate-pulse" />
      </>;
    case 'cosmic-star':
      return <div className="absolute inset-0 rounded-full border-2 border-indigo-500 animate-spin shadow-[0_0_12px_rgba(139,92,246,0.7)]" style={{ animationDuration: '8s' }} />;
    case 'legend-wings':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.7)]" />
      </>;
    case 'mythic-immortal':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-rose-600 animate-pulse shadow-[0_0_15px_rgba(244,63,94,0.8)]" />
        <div className="absolute -inset-1 rounded-full border border-dashed border-rose-400 animate-spin" style={{ animationDuration: '12s' }} />
      </>;
    case 'shadow-assassin':
      return <div className="absolute inset-0 rounded-full border-2 border-slate-600 shadow-[0_0_8px_rgba(15,23,42,0.9)]" />;
    case 'sakura-dream':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-pink-400 shadow-[0_0_6px_rgba(244,114,182,0.5)]" />
        <div className="absolute -top-0.5 right-1.5 text-[7px] text-pink-300 animate-pulse">🌸</div>
      </>;
    case 'abysm-lord':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-red-700 shadow-[0_0_14px_rgba(153,27,27,0.9)]" />
      </>;
    case 'star-guardian':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-sky-400" />
        <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 text-[9px] text-sky-300 animate-bounce">✦</span>
      </>;
    case 'dragon-soul':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-emerald-500" />
        <div className="absolute -inset-1 rounded-full border border-dashed border-emerald-400/50 animate-spin" style={{ animationDuration: '10s' }} />
        <span className="absolute right-0 top-0 text-[8px]">🐲</span>
      </>;
    case 'arcade-matrix':
      return <div className="absolute inset-0 rounded-full border-2 border-blue-500 border-dashed animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.5)]" />;
    case 'venom-pulse':
      return <>
        <div className="absolute inset-0 rounded-full border-[2.5px] border-green-500 shadow-[0_0_10px_rgba(34,197,94,0.8)]" />
        <div className="absolute inset-0.5 rounded-full border border-lime-400 animate-pulse" />
      </>;
    case 'gold-champion':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-yellow-600 shadow-[0_0_15px_rgba(202,138,4,0.8)]" />
        <div className="absolute inset-[1px] rounded-full border border-yellow-200" />
      </>;
    case 'celestial-god':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-indigo-100 shadow-[0_0_12px_rgba(254,240,138,0.8)] animate-pulse" />
        <div className="absolute -inset-1.5 rounded-full border border-yellow-200 animate-ping opacity-25" style={{ animationDuration: '4s' }} />
      </>;
    case 'void-wanderer':
      return <div className="absolute inset-0 rounded-full border-2 border-purple-600 shadow-[0_0_12px_rgba(168,85,247,0.7)] animate-pulse" />;
    case 'kiba-exclusive':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-t-amber-500 border-r-rose-600 border-b-amber-600 border-l-red-600 animate-spin" style={{ animationDuration: '2s' }} />
        <div className="absolute inset-[1.5px] rounded-full border border-yellow-300" />
        <div className="absolute -inset-1 rounded-full bg-amber-500/10 shadow-[0_0_20px_rgba(217,119,6,0.7)] animate-pulse" />
        <span className="absolute -top-1 right-2 text-[7px] animate-bounce">🔥</span>
      </>;
    case 'neon-shogun':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-fuchsia-500 shadow-[0_0_12px_rgba(217,70,239,0.8)]" />
      </>;
    case 'emerald-aurora':
      return <div className="absolute inset-0 rounded-full border-2 border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.7)] animate-pulse" />;
    case 'super-saiyan':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-amber-400 animate-pulse shadow-[0_0_18px_rgba(234,179,8,1)]" />
        <div className="absolute -inset-1 rounded-full border border-dashed border-cyan-400 animate-spin opacity-80" style={{ animationDuration: '4s' }} />
        <span className="absolute -top-1.5 left-2 animate-bounce text-[6.5px] text-yellow-300">⚡</span>
      </>;
    case 'sharingan-eye':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-red-600 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.9)]" />
        <div className="absolute inset-1 rounded-full border border-slate-950/40 animate-spin" style={{ animationDuration: '6s' }} />
      </>;
    case 'water-breathing':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-sky-500 shadow-[0_0_12px_rgba(14,165,233,0.85)] animate-pulse" />
        <span className="absolute -top-1 right-1 text-[8px]">🌊</span>
      </>;
    case 'sun-god':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-yellow-400 shadow-[0_0_16px_rgba(253,224,71,0.9)] animate-pulse" />
        <div className="absolute -inset-1.5 rounded-full border border-dashed border-white/60 animate-spin" style={{ animationDuration: '8s' }} />
      </>;
    case 'hollow-mask':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-stone-200 shadow-[0_0_14px_rgba(220,38,38,0.7)]" />
        <div className="absolute -inset-1 rounded-full border-2 border-red-600 border-t-transparent border-b-transparent animate-pulse" />
      </>;
    case 'shadow-sovereign':
      return <>
        <div className="absolute inset-0 rounded-full border-[2.5px] border-violet-600 shadow-[0_0_15px_rgba(124,58,237,0.9)]" />
        <div className="absolute -inset-1 rounded-full border-2 border-dashed border-purple-500 animate-spin opacity-50" style={{ animationDuration: '5s' }} />
        <span className="absolute -top-1 right-2.5 text-[7px]">🔮</span>
      </>;
    case 'domain-limitless':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-cyan-400 shadow-[0_0_14px_rgba(6,182,212,0.85)]" />
        <div className="absolute -inset-1 rounded-full border border-dashed border-cyan-300 animate-pulse" />
      </>;
    case 'curse-seal':
      return <>
        <div className="absolute inset-0 rounded-full border-2 border-orange-500 shadow-[0_0_12px_rgba(249,115,22,0.8)]" />
        <div className="absolute inset-0.5 rounded-full border border-dashed border-red-400 animate-spin" style={{ animationDuration: '7s' }} />
      </>;
    case 'thunder-god':
      return <>
        <div className="absolute inset-0 rounded-full border-[3px] border-yellow-300 shadow-[0_0_16px_rgba(253,224,71,0.8)] animate-pulse" />
        <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 text-[10px] animate-bounce">⚡</span>
      </>;
    default:
      return <div className="absolute inset-0 rounded-full border-2 border-amber-500/30" />;
  }
}

interface Props {
  avatarUrl: string;
  borderId?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  onClick?: () => void;
}

const SIZES = {
  sm: { outer: 'w-8 h-8',  img: 'w-6 h-6'    },
  md: { outer: 'w-10 h-10', img: 'w-7 h-7'   },
  lg: { outer: 'w-14 h-14', img: 'w-10 h-10' },
  xl: { outer: 'w-20 h-20', img: 'w-16 h-16' },
};

export default function AvatarWithBorder({ avatarUrl, borderId = 'default', size = 'md', className = '', onClick }: Props) {
  const s = SIZES[size];
  return (
    <div
      className={`relative flex items-center justify-center shrink-0 ${s.outer} ${className} ${onClick ? 'cursor-pointer' : ''}`}
      onClick={onClick}
    >
      {avatarUrl ? (
        <img src={avatarUrl} alt="avatar" className={`${s.img} rounded-full object-cover`} />
      ) : (
        <div className={`${s.img} rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400 text-xs font-black`}>KB</div>
      )}
      <BorderFrame id={borderId} />
    </div>
  );
}
