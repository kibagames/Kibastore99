import React from 'react';
import { motion } from 'motion/react';
import { ShoppingCart, Zap } from 'lucide-react';
import { DiamondPackage } from '../types';

const DIAMOND_IMG = 'https://i.imgur.com/34jMRi2.png';

interface Props {
  pkg: DiamondPackage;
  onSelect: (pkg: DiamondPackage) => void;
  type: 'login' | 'inmail';
}

export default function DiamondCard({ pkg, onSelect, type }: Props) {
  if (pkg.outOfStock) {
    return (
      <motion.div
        whileHover={{ scale: 1.01 }}
        className="relative flex items-center justify-between p-4 rounded-2xl border border-slate-800 bg-slate-900/30 opacity-60 cursor-not-allowed"
      >
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-xl border border-slate-700 bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
            <img src={DIAMOND_IMG} alt="diamonds" className="w-10 h-10 object-contain grayscale" />
          </div>
          <div>
            <div className="font-display font-black text-base text-slate-400">{pkg.diamonds} 💎</div>
            <div className="text-[10px] text-rose-400 font-mono font-bold uppercase">Out of Stock</div>
          </div>
        </div>
        <span className="font-mono font-black text-slate-500 text-lg">{pkg.price}</span>
      </motion.div>
    );
  }

  return (
    <motion.div
      whileHover={{ scale: 1.02, x: 2 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onSelect(pkg)}
      className="flex items-center justify-between p-4 rounded-2xl border border-slate-800 bg-slate-900/40 hover:border-amber-500/50 hover:bg-slate-900/80 transition-all cursor-pointer group"
    >
      <div className="flex items-center gap-3">
        <div className="w-14 h-14 rounded-xl border border-amber-500/20 bg-slate-950 flex items-center justify-center overflow-hidden shrink-0 group-hover:border-amber-500/60 transition-all">
          <img src={DIAMOND_IMG} alt="diamonds" className="w-11 h-11 object-contain drop-shadow-[0_0_8px_rgba(245,158,11,0.4)]" />
        </div>
        <div>
          <div className="font-display font-black text-base text-white">{pkg.diamonds} 💎</div>
          <div className="text-[10px] text-emerald-400 font-mono font-bold uppercase flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
            Available · Tap to order
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        <span className="font-mono font-black text-amber-400 text-lg bg-amber-950/20 border border-amber-900/40 px-3 py-1.5 rounded-xl">
          {pkg.price}
        </span>
        <div className="hidden sm:flex flex-col gap-1.5">
          <div className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 text-slate-950 text-[10px] font-black rounded-lg">
            <Zap size={11} /> Buy Now
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1.5 border border-slate-700 text-slate-300 text-[10px] font-bold rounded-lg">
            <ShoppingCart size={11} /> Cart
          </div>
        </div>
      </div>
    </motion.div>
  );
}
