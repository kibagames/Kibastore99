import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Save, Camera, User, Smartphone, Shield } from 'lucide-react';
import AvatarWithBorder, { AVATAR_BORDERS } from './AvatarWithBorder';

interface Profile {
  gamerTag: string;
  mlbbUid: string;
  serverId: string;
  whatsAppNumber: string;
  avatarUrl: string;
  borderId: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  googlePhotoURL?: string;
  googleDisplayName?: string;
}

const STORAGE_KEY = 'kiba-user-profile';

export function loadProfile(googlePhotoURL = '', googleDisplayName = ''): Profile {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch {}
  return { gamerTag: googleDisplayName || 'Gamer', mlbbUid: '', serverId: '', whatsAppNumber: '', avatarUrl: googlePhotoURL, borderId: 'default' };
}

export function saveProfile(p: Profile) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
}

export default function ProfileModal({ open, onClose, googlePhotoURL = '', googleDisplayName = '' }: Props) {
  const [profile, setProfile] = useState<Profile>(() => loadProfile(googlePhotoURL, googleDisplayName));
  const [saved, setSaved] = useState(false);
  const [tab, setTab] = useState<'avatar' | 'borders' | 'info'>('avatar');

  useEffect(() => {
    if (open) setProfile(loadProfile(googlePhotoURL, googleDisplayName));
  }, [open, googlePhotoURL, googleDisplayName]);

  const set = (k: keyof Profile, v: string) => setProfile(p => ({ ...p, [k]: v }));

  const handleSave = () => {
    saveProfile(profile);
    setSaved(true);
    setTimeout(() => { setSaved(false); onClose(); }, 1200);
  };

  const rarityColor: Record<string, string> = {
    Common: 'text-slate-400 bg-slate-800 border-slate-700',
    Rare: 'text-sky-400 bg-sky-950 border-sky-800',
    Epic: 'text-violet-400 bg-violet-950 border-violet-800',
    Legend: 'text-yellow-400 bg-yellow-950 border-yellow-800',
    Mythic: 'text-rose-400 bg-rose-950 border-rose-800',
    Collector: 'text-fuchsia-400 bg-fuchsia-950 border-fuchsia-800',
    Special: 'text-amber-400 bg-amber-950 border-amber-800',
  };

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <motion.div
            initial={{ scale: 0.93, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.93, opacity: 0, y: 20 }}
            transition={{ duration: 0.25 }}
            className="w-full max-w-md bg-slate-950 border border-amber-500/30 rounded-3xl overflow-hidden shadow-2xl shadow-amber-950/30 flex flex-col max-h-[90vh]"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 shrink-0">
              <div>
                <h2 className="font-display font-black text-white text-lg uppercase">Edit Profile</h2>
                <p className="text-[10px] text-slate-400 font-mono">Avatar · Borders · Info</p>
              </div>
              <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
                <X size={18} />
              </button>
            </div>

            <div className="flex flex-col items-center gap-3 py-5 border-b border-slate-800 shrink-0">
              <AvatarWithBorder avatarUrl={profile.avatarUrl} borderId={profile.borderId} size="xl" />
              <div className="text-center">
                <div className="font-display font-black text-white text-base">{profile.gamerTag || 'Gamer'}</div>
                <div className="text-[10px] text-amber-400 font-mono uppercase">{AVATAR_BORDERS.find(b => b.id === profile.borderId)?.name || 'Default'}</div>
              </div>
            </div>

            <div className="flex border-b border-slate-800 shrink-0">
              {(['avatar', 'borders', 'info'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`flex-1 py-3 text-xs font-bold uppercase tracking-wide transition-all ${tab === t ? 'text-amber-400 border-b-2 border-amber-400' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  {t === 'avatar' ? '📸 Avatar' : t === 'borders' ? '✨ Borders' : '📝 Info'}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {tab === 'avatar' && (
                <div className="space-y-4">
                  <label className="block space-y-1.5">
                    <span className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1.5"><Camera size={12} /> Avatar Image URL</span>
                    <input
                      type="url"
                      value={profile.avatarUrl}
                      onChange={e => set('avatarUrl', e.target.value)}
                      placeholder="https://... (paste any image link)"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-500"
                    />
                  </label>
                  {googlePhotoURL && (
                    <button
                      type="button"
                      onClick={() => set('avatarUrl', googlePhotoURL)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl border border-slate-700 hover:border-amber-500/40 bg-slate-900 transition-all text-left"
                    >
                      <img src={googlePhotoURL} alt="google" className="w-8 h-8 rounded-full object-cover" />
                      <span className="text-xs text-slate-300 font-medium">Use Google profile photo</span>
                    </button>
                  )}
                </div>
              )}

              {tab === 'borders' && (
                <div className="grid grid-cols-2 gap-2">
                  {AVATAR_BORDERS.map(border => {
                    const active = profile.borderId === border.id;
                    return (
                      <button
                        key={border.id}
                        onClick={() => set('borderId', border.id)}
                        className={`flex items-center gap-2.5 p-2.5 rounded-xl border transition-all text-left ${active ? 'border-amber-500/60 bg-amber-950/20 ring-1 ring-amber-500/20' : 'border-slate-800 hover:border-slate-700 bg-slate-900/50'}`}
                      >
                        <AvatarWithBorder avatarUrl={profile.avatarUrl} borderId={border.id} size="sm" />
                        <div className="min-w-0">
                          <div className="text-[11px] font-bold text-white truncate">{border.name}</div>
                          <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase border ${rarityColor[border.rarity]}`}>
                            {border.rarity}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {tab === 'info' && (
                <div className="space-y-4">
                  {[
                    { label: 'Gamer Tag / IGN', key: 'gamerTag', icon: <User size={12} />, placeholder: 'e.g. KIBA MASTER' },
                    { label: 'MLBB User ID', key: 'mlbbUid', icon: <Shield size={12} />, placeholder: 'e.g. 19582963' },
                    { label: 'Server ID', key: 'serverId', icon: <Shield size={12} />, placeholder: 'e.g. 2190' },
                    { label: 'WhatsApp Number', key: 'whatsAppNumber', icon: <Smartphone size={12} />, placeholder: '+91 9863068885' },
                  ].map(({ label, key, icon, placeholder }) => (
                    <label key={key} className="block space-y-1.5">
                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1.5">{icon} {label}</span>
                      <input
                        type="text"
                        value={(profile as any)[key]}
                        onChange={e => set(key as keyof Profile, e.target.value)}
                        placeholder={placeholder}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-500 placeholder:text-slate-500"
                      />
                    </label>
                  ))}
                </div>
              )}
            </div>

            <div className="px-5 py-4 border-t border-slate-800 shrink-0 flex gap-3">
              <button onClick={onClose} className="flex-1 py-3 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 font-bold text-sm transition-all">
                Cancel
              </button>
              <button
                onClick={handleSave}
                className={`flex-1 py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${saved ? 'bg-emerald-600 text-white' : 'bg-amber-500 hover:bg-amber-400 text-slate-950'}`}
              >
                <Save size={15} />
                {saved ? 'Saved!' : 'Save Profile'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
