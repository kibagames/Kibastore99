import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingCart, Trash2, Zap, MessageCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';
import DiamondCheckoutModal from './DiamondCheckoutModal';
import { DiamondPackage } from '../types';

const DIAMOND_IMG = 'https://i.imgur.com/34jMRi2.png';

interface StoreInfo {
  upiId: string;
  qrCodeUrl: string;
  paymentInstructions: string;
  whatsAppNumber: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  storeInfo: StoreInfo;
}

export default function CartDrawer({ open, onClose, storeInfo }: Props) {
  const { items, removeItem, clearCart } = useCart();
  const [checkoutPkg, setCheckoutPkg] = useState<{ pkg: DiamondPackage; type: 'login' | 'inmail' } | null>(null);

  const total = items.reduce((sum, item) => {
    const num = parseFloat(item.pkg.price.replace(/[^0-9.]/g, ''));
    return sum + (isNaN(num) ? 0 : num * item.qty);
  }, 0);

  return (
    <>
      <AnimatePresence>
        {open && (
          <div className="fixed inset-0 z-[150] flex justify-end">
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
              onClick={onClose}
            />

            <motion.div
              initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="relative w-full max-w-sm h-full bg-[#0b0f1a] border-l border-slate-800 flex flex-col shadow-2xl"
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-2">
                  <ShoppingCart size={18} className="text-amber-400" />
                  <h2 className="font-display font-black text-white text-lg uppercase">Cart</h2>
                  {items.length > 0 && (
                    <span className="bg-amber-500 text-slate-950 font-black text-xs px-2 py-0.5 rounded-full">{items.length}</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {items.length > 0 && (
                    <button onClick={clearCart} className="text-[10px] text-rose-400 hover:text-rose-300 font-bold uppercase flex items-center gap-1">
                      <Trash2 size={11} /> Clear
                    </button>
                  )}
                  <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
                    <X size={18} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {items.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full gap-4 text-slate-500 py-20">
                    <ShoppingCart size={48} className="opacity-20" />
                    <div className="text-center">
                      <div className="font-display font-bold text-lg text-slate-600">Cart is empty</div>
                      <div className="text-sm mt-1">Add diamond packages to get started</div>
                    </div>
                  </div>
                ) : (
                  items.map(item => (
                    <div key={item.pkg.id} className="flex items-center gap-3 p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                      <div className="w-12 h-12 rounded-xl bg-slate-950 border border-amber-500/20 flex items-center justify-center shrink-0">
                        <img src={DIAMOND_IMG} className="w-9 h-9 object-contain" alt="" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-white text-sm truncate">{item.pkg.diamonds} 💎</div>
                        <div className="text-[10px] text-slate-400 uppercase font-mono">{item.type === 'login' ? 'Via Login' : 'Via In-Mail'}</div>
                        <div className="text-amber-400 font-black text-sm mt-0.5">{item.pkg.price}</div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <button onClick={() => removeItem(item.pkg.id)} className="text-slate-600 hover:text-rose-400 transition-colors">
                          <Trash2 size={14} />
                        </button>
                        <button
                          onClick={() => setCheckoutPkg({ pkg: item.pkg, type: item.type })}
                          className="text-[10px] text-amber-400 font-bold hover:underline flex items-center gap-0.5"
                        >
                          <Zap size={10} /> Buy
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {items.length > 0 && (
                <div className="px-5 py-4 border-t border-slate-800 shrink-0 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 text-sm font-mono">Estimated Total</span>
                    <span className="text-amber-400 font-black text-xl">₹{total.toLocaleString('en-IN')}</span>
                  </div>
                  <a
                    href={`https://wa.me/${storeInfo.whatsAppNumber.replace(/\D/g, '')}?text=${encodeURIComponent(
                      `💎 KIBA OFFICIAL - Cart Order\n\n${items.map(i => `• ${i.pkg.diamonds} (${i.type === 'login' ? 'Via Login' : 'Via In-Mail'}) — ${i.pkg.price}`).join('\n')}\n\nTotal: ₹${total.toLocaleString('en-IN')}\n\nPlease share MLBB ID, Server ID & IGN to proceed.`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase text-sm transition-all"
                  >
                    <MessageCircle size={16} />
                    Order All via WhatsApp
                  </a>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {checkoutPkg && (
          <DiamondCheckoutModal
            pkg={checkoutPkg.pkg}
            type={checkoutPkg.type}
            storeInfo={storeInfo}
            onClose={() => setCheckoutPkg(null)}
          />
        )}
      </AnimatePresence>
    </>
  );
}
