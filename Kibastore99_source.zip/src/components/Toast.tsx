import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, AlertTriangle, Info } from 'lucide-react';

export interface ToastData {
  id: string;
  message: string;
  type: 'success' | 'warning' | 'info' | 'error';
}

interface Props {
  toasts: ToastData[];
  onRemove: (id: string) => void;
}

export default function Toast({ toasts, onRemove }: Props) {
  return (
    <div className="fixed top-4 right-4 z-[200] flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, x: 60, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 60, scale: 0.95 }}
            className="pointer-events-auto flex items-start gap-3 bg-slate-900 border border-slate-700 rounded-2xl p-4 shadow-2xl"
          >
            <span className={`shrink-0 mt-0.5 ${
              t.type === 'success' ? 'text-emerald-400' :
              t.type === 'warning' ? 'text-amber-400' :
              t.type === 'error'   ? 'text-rose-400'   : 'text-sky-400'
            }`}>
              {t.type === 'success' ? <CheckCircle size={18} /> :
               t.type === 'warning' ? <AlertTriangle size={18} /> : <Info size={18} />}
            </span>
            <p className="flex-1 text-xs text-slate-200 font-medium leading-snug">{t.message}</p>
            <button onClick={() => onRemove(t.id)} className="shrink-0 text-slate-500 hover:text-white">
              <X size={14} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
