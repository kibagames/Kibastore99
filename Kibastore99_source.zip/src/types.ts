export interface DiamondPackage {
  id: string;
  diamonds: string;
  price: string;
  outOfStock: boolean;
  type: 'login' | 'inmail';
  order?: number;
}

export interface SkinItem {
  id: string;
  name: string;
  hero: string;
  price: string;
  imageUrl: string;
  description: string;
  soldOut: boolean;
  order?: number;
}

export interface AccountItem {
  id: string;
  title: string;
  price: string;
  rank: string;
  heroCount: string;
  skinCount: string;
  description: string;
  imageUrl: string;
  soldOut: boolean;
  order?: number;
}

export interface BannerSlide {
  id: string;
  imageUrl: string;
  title: string;
  description: string;
  buttonText: string;
  buttonLink: string;
  order?: number;
}

export interface StoreSettings {
  storeName: string;
  whatsAppNumber: string;
  paymentInstructions: string;
  paymentMethods: string;
  qrCodeUrl: string;
  upiId: string;
}

export interface Order {
  id: string;
  packageName: string;
  price: string;
  uid: string;
  serverId: string;
  whatsAppNumber: string;
  paymentUtr: string;
  status: 'pending' | 'completed';
  userId: string;
  userEmail: string;
  createdAt: any;
  updatedAt: any;
}
